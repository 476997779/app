MIPS_SDK=/wykj/gcc/mips-gcc/mips-gcc472-glibc216-64bit

if [ ! -e out ];then
    mkdir out
fi
mips-linux-uclibc-gnu-gcc -c -fvisibility=hidden -O3 -Iinclude -Iinclude/wanyee -Iinclude/tutk -I${MIPS_SDK}/include -o out/wlink.cpp.o wlink.cpp
mips-linux-uclibc-gnu-gcc -c -fvisibility=hidden -O3 -Iinclude -Iinclude/wanyee -Iinclude/tutk -I${MIPS_SDK}/include -o out/ota.cpp.o ota.cpp
mips-linux-uclibc-gnu-ar -cr libs/libwlink.a out/wlink.cpp.o out/ota.cpp.o

mips-linux-uclibc-gnu-gcc -c -fvisibility=hidden -O3 -Iinclude -Iinclude/wanyee -Iinclude/protobuf -I${MIPS_SDK}/include -o out/zrt_sta_app.cpp.o zrt_sta_app.cpp
mips-linux-uclibc-gnu-g++ -o out/zrt_app out/zrt_sta_app.cpp.o -Llibs -Llibs/tutk -Llibs/mp4 -Llibs/protobuf -Wl,-rpath=$ORIGIN -s -fvisibility=hidden -L${MIPS_SDK}/lib -lwlink -lwanyee -lm -lrt -lpthread -lprotobuf-lite -lzrt_sta -lwywifi -lIOTCAPIs -lAVAPIs -lsCHL -lmp4record -lmp4v2 -lfdk-aac -lzlink

