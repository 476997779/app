#ifndef __KEY_HH__
#define __KEY_HH__

#include <linux/input.h>

typedef enum {
  KEY_EVENT_PRESSED,
  KEY_EVENT_RELEASED,
  KEY_EVENT_CLICK,
  KEY_EVENT_LONGPRESS,
} KeyEvent;

typedef enum {
	KEY_EVENT_BIND_CAMERA = 0,
} KEY_EVENT;

typedef int (*KeyEventNotify)(int event, char *data, int size);

int KeyInit(void);
int KeySetEventCallBack(KeyEventNotify cb);
int KeyExit(void);

#endif /* __KEY_HH__ */
