#ifndef __ZRT_STA_DAEMON_HH__
#define __ZRT_STA_DAEMON_HH__
/**
 * @file ZRT_Station_Daemon.hh
 * @brief
 * @author qli, 823258601@qq.com
 * @version 1
 * @date 2017-09-14
 */

typedef enum
{
    ZRT_STA_ALL_VER = 0,  /* 所有版本号 */
    ZRT_STA_LIB_VER,      /* 库的版本号 */
    ZRT_STA_DAEMON_VER    /* daemon 的版本号 */
} ZRT_STA_VERSION;

typedef enum {
    CAM_ONLINE  =  1,  /* 在线状态 */
    CAM_OFFLINE =  2, /* 离线状态 */
    CAM_NO_CAM  = -1,  /* 集合中没有设备 */
    CAM_ANOTHER = -2,  /* 保留 */
} CAMSTATUS;

typedef struct {
    char uid[128]; /* uid */
    char ip[16]; /* ip address */
	char mac[18]; /* mac address */
    int batteryCap;   /* 电量 */
    CAMSTATUS status; /* 状态信息 */
} ZRT_Camera;

/**
 * @brief ZRT_STA_INIT: 库的初始化;the first step
 *
 * @return success 0; error -1;
 */
int ZRT_STA_Init(void);

/**
 * @brief ZRT_STA_Init2: 库的初始化;the first step
 *
 * @param[in] cli: station 的名称，默认为zrt.sta.lib_app, cli为NULL，等价于ZRT_STA_Init(void);_
 *
 * @retval : 0 success;
 * @retval : -1 err;
 *
 * @attention
 */
int ZRT_STA_Init2(char *cli);

/**
 * @brief ZRT_STA_WakeupCam :通过uid唤醒设备, 该函数为阻塞函数
 *
 * @param uid :唯一标识 uid
 * @param timeout_sec : 超时时间, 单位秒; 若timeout_sec 为0时，默认为5s
 *
 * @return 成功返回 0; 失败返回 -1(camera 没有在timeout_sec时间内启动联网)
 */
int ZRT_STA_WakeupCam(const char *uid, int timeout_sec);

/**
 * @brief ZRT_STA_GetNumOfCameras: 获取当前station绑定的设备数
 *
 * @return : 成功:返回设备数, 失败:返回-1
 */
int ZRT_STA_GetNumOfCameras(void);

/**
 * @brief ZRT_STA_GetCameras: 获取camera的数组
 *
 * @param cams[]: 输出camera 集合(output)
 * @param max_cams: 获取cams的最大数量(input), 该函数返回数最大值
 *
 * @return: 返回当前绑定的camera数量, 失败返回-1
 */
int ZRT_STA_GetCameras(ZRT_Camera *cams, int max_cams);

/**
 * @brief ZRT_STA_StartBind: 设备绑定
 *
 * @param timeout_sec:    绑定扫描超时时间, 若在timeout_sec之内有一个Camera绑定,立即返回
 *
 * @return: 绑定成功0; 绑定失败-1;超时-2;
 */
int ZRT_STA_StartBind(int timeout_sec);

/**
 * @brief ZRT_STA_StartBind2: 设备绑定
 *
 * @param timeout_sec:    绑定扫描超时时间, 若在timeout_sec之内有一个Camera绑定,立即返回
 * @param result_uid[out] 输出绑定camera的UID
 *
 * @return: 绑定成功0; 绑定失败-1;超时-2;
 */
int ZRT_STA_StartBind2(int timeout_sec, char *result_uid);

/**
 * @brief ZRT_STA_GetCamStatusByUID : 通过uid获取设备状态信息
 *
 * @param uid:     uid
 * @param status:   输出设备状态信息
 *
 * @return  集合中没有设备返回-1; 成功返回 0;
 */
int ZRT_STA_GetCamStatusByUID(const char *uid, CAMSTATUS *status);

/**
 * @brief ZRT_STA_DelCameraByUID : 通过uid删除设备
 *
 * @param uid
 *
 * @return : 失败-1; 成功0;
 */
int ZRT_STA_DelCameraByUID(const char *uid);

/**
 * @brief ZRT_STA_SetMaxCam: 设置station接收绑定的最大数量
 *
 * @param[in] num: 设置最大数量
 *
 * @retval: 0 success
 * @retval: -1 error
 *
 * @attention
 */
int ZRT_STA_SetMaxCam(int num);

/**
 * @brief ZRT_STA_GetVersion : 根据选项， 获取lib的版本号，获取daemon的版本号
 *
 * @param[in] Ver : 选项
 *
 * @retval : NULL err;
 * @retval : not NULL success;
 *
 * @attention
 */
const char *ZRT_STA_GetVersion(ZRT_STA_VERSION Ver);


#endif
