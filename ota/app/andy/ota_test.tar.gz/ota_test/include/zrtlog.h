#ifndef __ZRTLOG_H__
#define __ZRTLOG_H__

#include <syslog.h>

#define VERBOSE_DBG

#define ZRTLOG_ERR(fmt, ...)	syslog(LOG_ERR, fmt, ##__VA_ARGS__)
#define ZRTLOG_WARN(fmt, ...)	syslog(LOG_WARNING, fmt, ##__VA_ARGS__)
#define ZRTLOG_INFO(fmt, ...)	fprintf(stderr, fmt, ##__VA_ARGS__)
#define ZRTLOG_DBG(fmt, ...)	syslog(LOG_DEBUG, fmt, ##__VA_ARGS__)
#ifdef VERBOSE_DBG
#define ZRTLOG_VERBOSE(fmt, ...)	syslog(LOG_DEBUG, "%s()[%d]:" fmt, __func__, __LINE__, ##__VA_ARGS__)
#else
#define ZRTLOG_VERBOSE(fmt, ...)
#endif

#endif /* __ZRTLOG_H__ */
