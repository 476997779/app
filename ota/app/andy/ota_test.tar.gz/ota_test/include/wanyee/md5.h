#ifndef __MD5_H__
#define __MD5_H__
typedef unsigned int DWORD;
typedef int INT;
typedef char BYTE;
typedef char TCHAR;
typedef unsigned int UINT;
#include <stdio.h>
  
extern int hmac_md5_hash(const char* inputBuffer, unsigned int inputCount, const char* userKey, unsigned int UserKeyLen, char* outputBuffer);
#endif
