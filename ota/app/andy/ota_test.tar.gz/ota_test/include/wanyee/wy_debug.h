#ifndef __WY_DEBUG_H__
#define __WY_DEBUG_H__

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <time.h>
#include <sys/time.h>

#define WY_DEBUG 1
//#undef WY_DEBUG



//#define WY_LOG_TO_FILE


#define RED_COLOR               "\33[1;31m"
#define GREEN_COLOR             "\33[1;32m"
#define YELLOW_COLOR            "\33[1;33m"

#ifdef WY_DEBUG
typedef uint64_t wy_clock_t;
static inline wy_clock_t wy_clock(void) {
    struct timeval tv; 
    gettimeofday(&tv, NULL);
    return (wy_clock_t)(tv.tv_sec) * 1000 + (wy_clock_t)(tv.tv_usec) / 1000;
}


#ifdef WY_LOG_TO_FILE
#define WY_LOG_FILE "/tmp/wy_log.txt"
static inline int write_logs(const char *buf, int len)
{
    FILE *fp = NULL;
    int ret = 0;

    fp = fopen(WY_LOG_FILE, "a+");
    if (NULL != fp) {
        ret = fwrite(buf, len, 1, fp);
        fclose(fp);

        return 0;
    }

    printf("%s:open %s failed\n", __func__,WY_LOG_FILE);
    return -1;
}

#define __wy_debug_printf(flag, fmt, ...) do { \
    char __log_buf[1024];\
    int __wy_log_ret;\
    int __wy_log_len = 0;\
    __wy_log_ret = snprintf(__log_buf, 1024, "[%llu.%llu]: %d|%s()|%s: ", \
                    wy_clock() / 1000, wy_clock() % 1000, \
                    __LINE__, __func__, flag); \
    __wy_log_len += __wy_log_ret;\
    __wy_log_ret = snprintf(__log_buf + __wy_log_ret, 1024 - __wy_log_ret, fmt, ##__VA_ARGS__);\
    __wy_log_len += __wy_log_ret;\
    write_logs(__log_buf, __wy_log_len);\
} while (0)
#else
#define __wy_debug_printf(flag, fmt, ...) do { \
    fprintf(stderr, "[%llu.%llu]: %d|%s()|%s: ", \
                    wy_clock() / 1000, wy_clock() % 1000, \
                    __LINE__, __func__, flag); \
    fprintf(stderr, fmt, ##__VA_ARGS__); \
} while (0)
#endif

/* 错误级别日志打印 */
#define wy_error(level, fmt, ...) do { \
    if (level > 0) \
        __wy_debug_printf(RED_COLOR"error"RED_COLOR, fmt, ##__VA_ARGS__); \
} while (0)

/* 警告级别日志打印 */
#define wy_warn(level, fmt, ...) do { \
    if (level > 1) \
        __wy_debug_printf("warn", fmt, ##__VA_ARGS__); \
} while (0)

/* 调试级别日志打印 */
#define wy_info(level, fmt, ...) do { \
    if (level > 2) \
        __wy_debug_printf("info", fmt, ##__VA_ARGS__); \
} while (0)

static inline void __wy_hexdump(const char *title, const unsigned char *data, int length) {
    int i;
    fprintf(stderr, "\n%s: \n", title);
    for (i = 0; i < length; ++i) {
        fprintf(stderr, "0x%02x, ", data[i]);
        if (((i + 1) % 8) == 0)
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");
}
#define wy_hexdump(level, title, data, len) do { \
    if (level > 2) \
        __wy_hexdump(title, data, len); \
} while (0)

#endif /* WY_DEBUG */

#include <stdlib.h>

#ifndef wy_error
#define wy_error(fmt, ...)    ((void)0)
#endif

#ifndef wy_warn
#define wy_warn(fmt, ...)     ((void)0)
#endif

#ifndef wy_info
#define wy_info(fmt, ...)     ((void)0)
#endif

#ifndef wy_hexdump
#define wy_hexdump(fmt, ...) ((void)0)
#endif

#endif /* __WY_DEBUG_H__ */
