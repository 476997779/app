#ifndef __P2P_MSG_H__
#define __P2P_MSG_H__



typedef enum __msg_type {
	/* Video */
	MSG_TYPE_VIDEO_SET_RESOLUTION			= 0x1000,
	MSG_TYPE_VIDEO_GET_RESOLUTION			= 0x1001,

	MSG_TYPE_VIDEO_SET_MIRROR				= 0x1002,
	MSG_TYPE_VIDEO_GET_MIRROR				= 0x1003,

	MSG_TYPE_VIDEO_SET_FILP					= 0x1004,
	MSG_TYPE_VIDEO_GET_FILP					= 0x1005,

	MSG_TYPE_VIDEO_SET_IRCUT				= 0x1006,
	MSG_TYPE_VIDEO_GET_IRCUT				= 0x1007,

	MSG_TYPE_VIDEO_RECORD_START				= 0x1008,
	MSG_TYPE_VIDEO_RECORD_STOP				= 0x1009,

	MSG_TYPE_VIDEO_REQUEST_IDR				= 0x100a,

	MSG_TYPE_VIDEO_SET_BITRATE				= 0x100b,
	MSG_TYPE_VIDEO_GET_BITRATE				= 0x100c,

	/* Audio */
	MSG_TYPE_AUDIO_SET_PLAY_VOL				= 0x1100, //室外铃声和对讲音量
	MSG_TYPE_AUDIO_GET_PLAY_VOL				= 0x1101,
	MSG_TYPE_AUDIO_SET_STA_RING_VOL			= 0x1102, //室内铃声音量
	MSG_TYPE_AUDIO_GET_STA_RING_VOL			= 0x1103,
    MSG_TYPE_RING_LED_SET_ENABLE            = 0x1104, //门铃 LED 开关
    MSG_TYPE_RING_LED_GET_ENABLE            = 0x1105,
	MSG_TYPE_GET_FREMOVE					= 0x1106,
	MSG_TYPE_SET_FREMOVE					= 0x1107,

	/* Status */
	MSG_TYPE_STATUS_GET_DEV_INFO			= 0x1200,
	MSG_TYPE_STATUS_GET_ALL_INFO			= 0x1203,

	/* Alarm */
	MSG_TYPE_ALARM_GET_INFO					= 0x1300,

	/* Power */
	MSG_TYPE_POWER_GET_PIR					= 0x1400,
	MSG_TYPE_POWER_SET_PIR					= 0x1401,

    /*Ring*/
    MSG_TYPE_APP_RING_ANSWERED                   = 0x1500,
    MSG_TYPE_APP_RING_HUNGUP                     = 0x1501,
    MSG_TYPE_APP_RING_TIMEOUT                    = 0x1502,

    MSG_TYPE_OTA_START                      = 0x1600,
    MSG_TYPE_OTA_ADDR_STATION               = 0x1601,
    MSG_TYPE_OTA_ADDR_CAMERA                = 0x1602,
    MSG_TYPE_OTA_ADDR_WIFI                  = 0x1603,
    MSG_TYPE_OTA_FINISH                     = 0x1604,


    MSG_TYPE_REMOTE_RING                    = 0x8888,

    /* disconnect */
    MSG_TYPE_CLOSE_SESSION					= 0x2000,

} P2P_MSG_TYPE;

enum {
    OTA_RESULT_SUCCESS          = 0x0,
    OTA_RESULT_BATTERY_LOW      = 0x1,
    OTA_RESULT_CHECK_ERROR      = 0x2,
    OTA_RESULT_VERSION_ERROR    = 0x3,
};

struct wy_ota_result {
    char result;
    char o_ver[64];
    char n_ver[64];
};

/* Status */
enum {  // 电池充放电状态
    BAT_DISCHARGING = 0,
    BAT_CHARGING,
    BAT_FULL,
};

struct wy_bat_status{
    char capacity;   // 电量信息
    char chgst;      // 充放电状态

};

struct wy_pir_status {
    char pir_det_onoff;          /* 关闭:0,  开启：1 */
    char pir_det_range;          /* 近:  0,  中: 1, 远：2 */

};

struct wy_dev_info {
    char in_vol;            /* 0 ~ 100  */
    char out_vol;           /* 0 ~ 100  */
    char infrared_mode;     /* 始终关闭：0 , 始终开启： 1,  自动切换: 2  */
    char ring_key_led_onoff; /* 关闭:0,  开启：1 */
    char fremove_onoff;         /* 关闭:0,  开启：1 */  
    char wifi_strong;
    char cam_ver[64];
    char wifi_ver[64];
    char sta_ver[64];
    struct wy_bat_status    bat_st;
    struct wy_pir_status    pir_st;

};

enum { // 分辨率级别
	VIDEO_RESOLUTION_LOW    = 0,      // 低分辨率
	VIDEO_RESOLUTION_MIDDLE = 1,      // 中分辨率
	VIDEO_RESOLUTION_HIGH   = 2,      // 高分辨率
};

struct wy_video_resolution {  // 分辨率信息
    int lvl;
	int width;					// 宽
	int height;					// 高
};

struct wy_save_flash_info {
    char name[64];
    char md5[32];
    int index;
    struct wy_dev_info wdinfo;
    struct wy_video_resolution wvres;
    struct wy_save_flash_info *next;
};

#endif //__P2P_MSG_H__
