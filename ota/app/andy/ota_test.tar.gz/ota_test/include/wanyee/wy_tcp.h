#ifndef __WY_TCP_H__
#define __WY_TCP_H__

int tcp_listen(int port);
int send_data_to_tcp_server(const char *ip, int port, char *data, int dlen);

#endif
