#ifndef __WY_UDP_H__
#define __WY_UDP_H__

int wy_udp_push_msg(const char *ip, unsigned short port, const char *msg, int len);

#endif
