
#ifndef __MP4RECORD_H__
#define __MP4RECORD_H__

void *ZRT_Mp4Record_Create(char *UID, char *name, int video_width, int video_height, int fps);
int ZRT_Mp4Record_SaveAudio(void *handler, unsigned char *buf, int size);
int ZRT_Mp4Record_SaveVideo(void *handler, unsigned char *data, int size, int flags);
char *ZRT_Mp4Record_Stop(char *UID, void *handler);

#endif
