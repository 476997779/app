#ifndef __WY_WLINK_H__
#define  __WY_WLINK_H__

enum {
    RING_STAT_UNKNOW            = 0x0,
    RING_STAT_ANSWERED          = 0x01,
    RING_STAT_HUNGUP            = 0x02,
    RING_STAT_TIMEOUT           = 0x03,
};

void wy_set_ring_status(const char *cameraName, int status);
int wy_get_ring_status(const char *cameraName);
void wy_set_camera_status_wakeuping(const char *cameraName);
int wy_wifi_control_close_camera(const char *cameraName, int force);
int wlink_station_process_ioctl(const char *name, int type, int avIndex, char *buf, int size);
#endif
