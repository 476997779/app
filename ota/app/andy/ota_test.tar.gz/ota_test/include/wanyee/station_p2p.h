#ifndef __STATION_P2P_H__
#define __STATION_P2P_H__

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/prctl.h>

/* Thread name */
#define SET_THREAD_NAME(name) (prctl(PR_SET_NAME, (unsigned long)name))

#define CAMERA_NAME_MAX_LEN 32
#define MAX_CLIENT_NUMBER 8
#define MAX_SIZE_IOCTRL_BUF 1024

#if 1
#define IMP_LOG_INFO(TAG, fmt, ...) printf(fmt, ##__VA_ARGS__)
#define IMP_LOG_ERR(TAG, fmt, ...) fprintf(stderr, fmt, ##__VA_ARGS__)
#define IMP_LOG_WARN(TAG, fmt, ...) printf(fmt, ##__VA_ARGS__)

#else
#define IMP_LOG_INFO(TAG, fmt, ...)
#define IMP_LOG_ERR(TAG, fmt, ...)
#define IMP_LOG_WARN(TAG, fmt, ...)
#endif

typedef enum {
	CAM_ST_SLEEP = 0,
	CAM_ST_WAKE = 1,
	CAM_ST_BIND = 2,
	CAM_ST_UNBIND = 3,
} CAMERA_STATUS;

typedef enum {
	IOTYPE_USER_IPCAM_CLOSE_SESSION = 100001,
	IOTYPE_USER_IPCAM_BIND_CAMERA = 100002,
} P2P_CUSTOM_IOCTL_TYPE;

typedef enum {
	EVENT_CAMERA_ZLINK_ONLINE = 0,
	EVENT_CAMERA_ZLINK_OFFLINE,
	EVENT_CAMERA_MSG_PUSH,
} P2P_CUSTOM_EVENT_TYPE;

typedef struct __p2p_custom_callback {
	/* Audio Video Switch APIs */
	int (*P2P_Custom_Video_Switch)(int SID, char *cameraName, bool en);
	int (*P2P_Custom_Audio_Switch)(int SID, char *cameraName, bool en);
	int (*P2P_Custom_Audio_Play)(char *cameraName, unsigned char *buf, int size);

	/* P2P With ZLink Bind APIs */
	int (*P2P_Custom_BindCameraWithZLink)(char *cameraName, int SID);
	int (*P2P_Custom_UnBindCameraWithZLink)(char *cameraName, int SID);
	int (*P2P_Custom_CheckCameraStatus)(char *cameraName, CAMERA_STATUS *status);

	/* P2P Msg and other APIs */
	int (*P2P_Custom_Msg_Process)(char *cameraName, char *buf, int size, int type, char *result, int maxSize);
	int (*P2P_Custom_Request_IDR)(char *cameraName);
} ZRTP2PCustomCallBack;

typedef struct __p2p_custom_func {
	/* Set P2P Callback APIs */
	int (*P2P_Custom_Set_CallBack)(ZRTP2PCustomCallBack *callback);

	/* Audio Video APIs */
	int (*P2P_Custom_Send_Video_Frame)(int SID, unsigned char *buf, int size, int flag, int seq, unsigned long long timestamp);
	int (*P2P_Custom_Send_Audio_Frame)(int SID, unsigned char *buf, int size, unsigned long long timestamp);

	int (*P2P_Custom_Event)(char *cameraName, int event, char *data, int size);

	/* P2P Init and DeInit APIs */
	int (*P2P_Custom_Init)(char *UID, char *user, char *pass);
	int (*P2P_Custom_DeInit)(void);

} ZRTP2PCustomFunc;

extern ZRTP2PCustomFunc g_P2PCustomFunc;

#endif //__STATION_P2P_H__

