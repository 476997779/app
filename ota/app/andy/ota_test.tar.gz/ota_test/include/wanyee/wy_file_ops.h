#ifndef __WY_FILE_OPS_H__
#define __WY_FILE_OPS_H__
char *wy_file_get_name_from_absolute_path(const char *name);
int wy_delete_file(const char* path);
int wy_check_sdcard(void);

#define MP4_RECORD_PATH_SD "/mnt"
#define MP4_RECORD_PATH_TMP     "/tmp/video"
#define MP4_RECORD_PATH_CONFIG "/config/video"

#endif
