#ifndef __WY_PUSH_H__
#define __WY_PUSH_H__

int wy_push_msg(unsigned char *msg, int len, int port);
//int wy_push_video_msg(char *uid, int type, char *name);

enum {
    WY_MSG_FLAG_RING = 0x01,
    WY_MSG_FLAG_PIR = 0x02,
    WY_MSG_FLAG_FREMOVE = 0x04,
    WY_MSG_FLAG_VIDEO = 0x100,

    WY_MSG_FLAG_VIDEO_RING      = WY_MSG_FLAG_VIDEO | WY_MSG_FLAG_RING,
    WY_MSG_FLAG_VIDEO_PIR       = WY_MSG_FLAG_VIDEO | WY_MSG_FLAG_PIR,
    WY_MSG_FLAG_VIDEO_FREMOVE   = WY_MSG_FLAG_VIDEO | WY_MSG_FLAG_FREMOVE,
};

int wy_push_msg_queue_add_msg(int flag, int delay, char *uuid, char *video_name);


#define WY_PUSH_SERVER_IP "139.129.100.26"
#define WY_PUSH_VIDEOI_MSG_TCP_PORT 8000
#define WY_PUSH_NORMAL_MSG_TCP_PORT 8000

#endif
