#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <dlfcn.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <errno.h>
#include <wy_wakeup.h>
#include <wy_device.h>
#include <wy_wlink.h>

#include "zrt_inf.h"
#include "zrtlog.h"
#include "Key.hh"
#include "Led.hh"
#include "ZRTCommand.h"
#include "protobuf/ZRTCommand.pb.h"
#include "protobuf/ZRTStation.pb.h"
#include "zrt_app_config.h"

#define ZRT_STA_SUCCESS 0
#define ZRT_STA_FAILED -1
#define PROTOBUF_BUFFER_RESP_SIZE 128

extern "C" {
#include "ZRT_Station_Daemon.hh"
}

char gUID[32] = { 0 };
GetVersion funcGetVersion;
GetUID funcGetUID;
DTServerInit funcDTServerInit;
DTServerExit funcDTServerExit;
DTEventNotify funcDTEventNotify = NULL;

int SendStationSN(struct sockaddr_in *to)
{
	int sockfd, len;

	if ((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0) {
		ZRTLOG_ERR("%s[%d]socket error:%s", __func__, __LINE__, strerror(errno));
		return -1;
	}

	if (connect(sockfd, (struct sockaddr *)to, sizeof(struct sockaddr)) < 0) {
		ZRTLOG_ERR("%s[%d]connect error:%s", __func__, __LINE__, strerror(errno));
		return -1;
	}

	if ((len = send(sockfd, gUID , strlen(gUID),0)) < 0) {
		ZRTLOG_ERR("%s[%d]send error:%s", __func__, __LINE__, strerror(errno));
		return -1;
	}

	close(sockfd);

	ZRTLOG_DBG("Send SN(%s,%d)", gUID, len);

	return 0;
}

void *BroadcastListenerThread(void *data)
{
    int sock = (int)data;

    uint8_t *recv_buf = (uint8_t *)malloc(CONFIG_UDP_BROADCAST_BUFFER_SIZE);
    if (recv_buf == NULL) {
        ZRTLOG_ERR("malloc listener buffer failed\n");
        goto out;
    }

    struct sockaddr_in from;
    bzero(&from, sizeof(struct sockaddr_in));
    from.sin_family = AF_INET;
    from.sin_addr.s_addr = htonl(INADDR_ANY);
    from.sin_port = htons(CONFIG_UDP_BROADCAST_PORT);

    ZRTLOG_INFO("Start to listen broadcast");

    while(1) {
        int len = sizeof(struct sockaddr_in);
        int ret = recvfrom(sock,
                           recv_buf,
                           CONFIG_UDP_BROADCAST_BUFFER_SIZE,
                           0,
                           (struct sockaddr *)&from, (socklen_t*)&len);
        if (ret <= 0) {
            ZRTLOG_ERR("Broadcast recvfrom error:%s\n", strerror(errno));
        } else {
            ZRTLOG_INFO("Get broadcast msg from[%s]", inet_ntoa(from.sin_addr));
            if (*(uint16_t *)recv_buf == 0xc309) {
                ZRTLOG_INFO("Client request SN");
                from.sin_port = htons(CONFIG_UDP_BROADCAST_PORT);
                int retrt_cnt = 3;
                while (retrt_cnt--) {
                    if (SendStationSN(&from) == 0)
                        break;
                }
            }
        }
    }
    free(recv_buf);
out:
    close(sock);

    return NULL;
}


int BroadcastListenerInit(void)
{
    struct sockaddr_in addr_to;
    bzero(&addr_to, sizeof(struct sockaddr_in));
    addr_to.sin_family = AF_INET;
    addr_to.sin_addr.s_addr = htonl(INADDR_ANY);
    addr_to.sin_port = htons(CONFIG_UDP_BROADCAST_PORT);

    int sock = -1;
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        ZRTLOG_ERR("socket error:%s\n", strerror(errno));
        return -1;
    }

    int ret;
    int opt = 1;
    ret = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));
    if (ret == -1) {
        ZRTLOG_ERR("setsockopt error:%s\n", strerror(errno));
        return -1;
    }

    if (bind(sock, (struct sockaddr *)&(addr_to), sizeof(struct sockaddr_in)) < 0) {
        ZRTLOG_ERR("bind error:%s\n", strerror(errno));
        return -1;
    }

    pthread_t blthread;

    pthread_create(&blthread, NULL, BroadcastListenerThread, (void *)sock);
    pthread_detach(blthread);

    return 0;
}

int fill_caminfo(void *buf)
{
    int cam_num = 8;
/*
    存在bug的地方，目前绕过
    cam_num = ZRT_STA_GetNumOfCameras();
    if(cam_num < 0) {
        ZRTLOG_INFO("ZRT_STA_GetNumOfCameras error");
        return 0;
    }
*/
    ZRT_Camera cams[cam_num];

    ZRTCameraStatus *cam_status;
    ZRTStationStatus sta_status;
    sta_status.set_nr_cams(cam_num);

    int num = ZRT_STA_GetCameras(cams, cam_num);
    if (num < 0) {
        ZRTLOG_INFO("%s: ZRT_STA_GetCameras error", __func__);
//        free(cams);
        return 0;
    }

    int cam_net_state = 0;
    for(int i = 0; i < num; i++) {
        cam_status = sta_status.add_cam_status();
        cam_status->set_sn(cams[i].uid);
        if (!wy_station_is_route()) {
            if(cams[i].status == CAM_ONLINE){
                cam_net_state = ZRT_CAMERA_STATUS_ONLINE;
            }else if(cams[i].status == CAM_OFFLINE)
            {
                cam_net_state = ZRT_CAMERA_STATUS_OFFLINE;
            }
        } else {
            if (wy_camera_is_online_by_mac(cams[i].mac)) {
                cam_net_state = ZRT_CAMERA_STATUS_ONLINE;
            } else {
                cam_net_state = ZRT_CAMERA_STATUS_OFFLINE;
            }
        }

        cam_status->set_status(cam_net_state);
        cam_status->set_batcap(cams[i].batteryCap);
    }

    int length = sta_status.ByteSize();
    sta_status.SerializeToArray(buf, length);
    return length;

}

int HandleData(ZRTDTSession *session, void *rxBuf, int rxBufLen, void *txBuf, int txBufLen)
{
	int followed_len = 0, resp_value = ZRT_SERVER_RESP_FAILED, ret;
	ZRTClientCMD cmd;

	ZRTLOG_VERBOSE("handle data len=%d", rxBufLen);
	if (cmd.ParseFromArray(rxBuf, rxBufLen) == false) {
		ZRTLOG_ERR("Parse CMD failed, invali cmd");
		return -1;
	}

    fprintf(stderr, "cmd.index = 0x%x\n", cmd.index());
	switch (cmd.index()) {
    case ZRT_STATION_CMD_WAKEUP_CAM:
        //ret = ZRT_STA_WakeupCam(cmd.arg_str().c_str(), 5);
        printf("wakeup: %s\n", cmd.arg_str().c_str());
        ret = wy_wakeup_camera(cmd.arg_str().c_str(), 10);
        switch(ret) {
        case ZRT_STA_SUCCESS:
            ZRTLOG_INFO("Wake Up Camera(%s) success", cmd.arg_str().c_str());
                resp_value = ZRT_SERVER_RESP_OK;
            break;
        case ZRT_STA_FAILED:
            ZRTLOG_INFO("Wake Up Camera(%s) error", cmd.arg_str().c_str());
                resp_value = ZRT_SERVER_RESP_FAILED;
            break;
        }
        break;

    case ZRT_STATION_CMD_CLOSE_CAM:
    {
        printf("close camera: %s\n", cmd.arg_str().c_str());
        ret = wy_wifi_control_close_camera(cmd.arg_str().c_str(), 0);
        if (ret == 0) {
            resp_value = ZRT_SERVER_RESP_OK;
        } else {
            resp_value = ZRT_SERVER_RESP_FAILED;
        }

        break;
    }
    case ZRT_STATION_CMD_DELETE_CAM:
        ret = ZRT_STA_DelCameraByUID(cmd.arg_str().c_str());
        switch(ret)
        {
        case ZRT_STA_SUCCESS:
            ZRTLOG_INFO("Remove Camera(%s) Success", cmd.arg_str().c_str());
            resp_value = ZRT_SERVER_RESP_OK;
            break;
        case ZRT_STA_FAILED:
            resp_value = ZRT_SERVER_RESP_FAILED;
            ZRTLOG_INFO("Remove Camera(%s) error", cmd.arg_str().c_str());
            break;
        }
        break;

    case ZRT_STATION_CMD_QUERY_STATUS:
        resp_value = ZRT_SERVER_RESP_OK;
        followed_len = fill_caminfo(txBuf);
        break;
    default:
        resp_value = ZRT_SERVER_RESP_FAILED;
        ZRTLOG_WARN("Unknown cmd:%d\n", cmd.index());
        break;
    }

    ZRTServerRESP resp;
    int resp_len;
    uint8_t resp_buf[PROTOBUF_BUFFER_RESP_SIZE];

    resp.set_ret(resp_value);
    resp_len = resp.ByteSize();
    resp.SerializeToArray(resp_buf, resp_len);

    ret = session->SendData(resp_buf, resp_len);
    if (ret != resp_len) {
        ZRTLOG_ERR("SendData resp error:%d", ret);
        return -1;
    }

    if (followed_len) {
        ret = session->SendData(txBuf, followed_len);

        if (ret != followed_len) {
            ZRTLOG_ERR("SendData followed data error %d, %d", ret, followed_len);
            return -1;
        }
    }

	return 0;
}

#if 0
static int LoadSharedFunctions(void)
{
	void *h = dlopen("libdt.so", RTLD_LAZY | RTLD_GLOBAL);
	if (h == NULL) {
		ZRTLOG_ERR("open libdt.so failed: %s", dlerror());
		return -1;
	}

	dlerror();

	funcGetVersion = (GetVersion)dlsym(h, "ZRT_INF_GetVersion");
	funcGetUID = (GetUID)dlsym(h, "ZRT_INF_GetUID");
	funcDTServerInit = (DTServerInit)dlsym(h, "ZRT_INF_DTServerInit");
	funcDTServerExit = (DTServerExit)dlsym(h, "ZRT_INF_DTServerExit");
	funcDTEventNotify = (DTEventNotify)dlsym(h, "ZRT_INF_Event_Notify");

	if (funcGetVersion == NULL) {
		ZRTLOG_ERR("Cannot find symbol ZRT_INF_GetVersion: %s", dlerror());
		return -1;
	} else if (funcGetUID == NULL) {
		ZRTLOG_ERR("Cannot find symbol ZRT_INF_GetUID: %s", dlerror());
		return -1;
	} else if (funcDTServerInit == NULL) {
		ZRTLOG_ERR("Cannot find symbol ZRT_INF_DTServerInit: %s", dlerror());
		return -1;
	} else if (funcDTServerExit == NULL) {
		ZRTLOG_ERR("Cannot find symbol ZRT_INF_DTServerExit: %s", dlerror());
		return -1;
	} else {
		const char *dtversion = funcGetVersion();
		if (dtversion == NULL) {
			ZRTLOG_ERR("Invalid libdt verion");
			return -1;
		}
		ZRTLOG_INFO("libdt symbol load done. Version: %s", dtversion);
	}

	return 0;
}
#endif

int BasicInit(void)
{
    int ret = 0;
    /* Init log */
    openlog("zrt_sta", LOG_CONS | LOG_PID | LOG_PERROR, LOG_USER);
    ZRTLOG_INFO("Zeratul built: %s %s", __DATE__, __TIME__);

/*
 *   	ret = LoadSharedFunctions();
 *    if (ret < 0) {
 *        ZRTLOG_INFO("LoadSharedFunctions failed");
 *        return -1;
 *    }
 *
 */
    ret = KeyInit();
    if (ret < 0) {
        ZRTLOG_INFO("KeyInit failed-----\n");
        return -1;
    }
#if 0
	ret = KeyInit();
	if (ret < 0) {
		ZRTLOG_INFO("KeyInit failed");
		return -1;
	}
#endif

	KeySetEventCallBack(funcDTEventNotify);
    if (!wy_station_is_route()) {
        printf("+++++++++++++++LED init ......\n");
        ret = LedInit();
        if (ret < 0) {
            ZRTLOG_INFO("LedInit failed");
            return -1;
        }
    } else {
        printf("++++++++++++++++This is route\n");
        //route led init
    }

	return ret;
}

int wlink_servers_init(void);
int wy_push_msg_thread_init(void);
int main()
{
    int ret = 0;

    ret = BasicInit();
    if(ret < 0 ) {
        ZRTLOG_INFO("BasicInit() error\n");
        return -1;
    }

    ret = ZRT_STA_Init();
    if(ret < 0) {
        ZRTLOG_ERR("ZRT_STA_Init() error");
        return -1;
    }

    ret = wy_push_msg_thread_init();
    if (ret < 0) {
        printf("wy push msg thread_init failed\n");
        return -1;
    }

    ret = wlink_servers_init();
    if (ret < 0) {
        printf("wlink_servers_init failed\n");
        return -1;
    }

	ret = ZRT_INF_DTServerInit(HandleData);
	if (ret < 0) {
        ZRTLOG_ERR("ZRT_INF_DTServerInit() failed");
        return -1;
	}

    ret = ZRT_INF_GetUID(gUID, 31);
	if (ret < 0) {
        ZRTLOG_ERR("ZRT_INF_GetUID() failed");
        return -1;
	}

#if 1
    ret = BroadcastListenerInit();
	if (ret < 0) {
		ZRTLOG_ERR("BroadcastListenerInit() failed");
		return -1;
	}
#endif


    wy_reboot_remote_wifi_module();
    printf("\n=====================station Version: V0.0.10 bate2 =================\n");
    while(1)
        sleep(100);

    return 0;
}

