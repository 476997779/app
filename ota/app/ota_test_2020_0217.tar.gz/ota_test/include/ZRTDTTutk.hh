#ifndef __ZRTDTTUTK_HH__
#define __ZRTDTTUTK_HH__

#include <set>
#include <string>

#include <pthread.h>
#include <ZRTDT.hh>

using namespace std;

#define SESSION_CLOSE_BY_REMOTE -1
#define REMOTE_TIMEOUT_DISCONNECT -2

class ZRTDTSessionTUTK : ZRTDTSession {
public:
  ZRTDTSessionTUTK(int sessID);
  ~ZRTDTSessionTUTK();

  /* Interface implement. */
  int PreInit(void);
  void OnSessionError(void);
  int SendData(void *data, int count);
  int RecvData(void *data, int maxLen);

  int SwitchToChannel(int channel);
  int CurrentChannel(void) { return mCurrentChannel; }

  int SID(void) { return mSessionID; }

private:
  int TurnOnChannel(int channel);
  int TurnOffChannel(int channel);

private:
  int mSessionID;
  set<int> mActiveChannel;
  int mCurrentChannel;
  int mErrcode;
};

class ZRTDTServerTUTK : public ZRTDTServer {
public:
  static ZRTDTServerTUTK* GetInstance(const char *uid, void (onSessionCreate)(void *));

  ZRTDTServerTUTK(const char *uid, void (onSessionCreate)(void *));
  ~ZRTDTServerTUTK();

  /* Interface implement. */
  int Login(void);

  void LoginThread(void);
  bool IsLoginSuccess(void) { return mIsLogin; }

  void Run(void);
  void Stop(void);
  void ListenThread(void);

  ZRTDTSession* CreateNewSession(void *data);
  void DeleteSession(ZRTDTSession *session);

private:
  set<ZRTDTSessionTUTK> mActiveSessionSet;
  string mUID;
  bool mIsLogin;
  pthread_t mThread;
  void (*mOnSessionCreate)(void *);
};

#endif /* __ZRTDTTUTK_HH__ */
