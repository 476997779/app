#ifndef __WY_TET_H__
#define __WY_TET_H__
//#define WLINK_TEST

#define WLINK_TEST_THREAD
//#define WLINK_TEST_REMOTE_RING
//#define WLINK_TEST_REMOTE_WAKEUP

#endif
