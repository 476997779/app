#ifndef __WY_DEVICE_H__
#define __WY_DEVICE_H__
int wy_camera_is_online_by_mac(const char *mac_addr);
int wy_station_is_route(void);

const char *GetUid(void);
#endif
