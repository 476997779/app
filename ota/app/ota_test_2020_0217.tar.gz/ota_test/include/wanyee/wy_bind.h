#ifndef __WY_BIND_H__
#define __WY_BIND_H__

int parse_qrcode_and_run(const char *qrcode, int len);
#endif
