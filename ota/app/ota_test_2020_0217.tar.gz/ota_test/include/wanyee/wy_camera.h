#ifndef __WY_CAMERA_H__
#define __WY_CAMERA_H__

extern "C" {
#include "ZRT_Station_Daemon.hh"
};

#define MAX_SUB_CAMERA_NUM 8

enum {
    WY_CAMERA_STAT_ONLINE  =  1,  /* 在线状态 */
    WY_CAMERA_STAT_OFFLINE =  2, /* 离线状态 */
    WY_CAMERA_STAT_NO_CAM  = -1,  /* 集合中没有设备 */
    WY_CAMERA_STAT_ANOTHER = -2,  /* 保留 */
};

struct wy_camera{
    char uid[128]; /* uid */
    char ip[16]; /* ip address */
	char mac[18]; /* mac address */
    int batteryCap;   /* 电量 */
    int status; /* 状态信息 */
};


int wy_get_cameras(struct wy_camera *cams, int max_num);
int wy_upd_push_msg_to_all_cameras(const char *msg, int len);
int wy_udp_push_msg_to_one_camera(const char *uuid, const char *msg, int len, int count, int delay_ms);

#endif
