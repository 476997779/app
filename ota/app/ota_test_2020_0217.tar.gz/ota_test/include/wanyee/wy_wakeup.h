#ifndef __WY_WAKEUP_H__
#define  __WY_WAKEUP_H__

int wy_wakeup_camera(const char *uuid, int timeout_s);
int wy_reboot_remote_wifi_module(void);
int wy_reboot_remote_wifi_module_by_uuid(const char *uuid);
void notify_wakeup_done(void);
#endif
