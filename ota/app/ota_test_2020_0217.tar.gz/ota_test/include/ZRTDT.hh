#ifndef __ZRTDT_HH__
#define __ZRTDT_HH__

class ZRTDTSession {
public:
  virtual ~ZRTDTSession() {};

  virtual int PreInit(void) = 0;
  virtual void OnSessionError(void) = 0;

  virtual int SendData(void *data, int count) = 0;
  virtual int RecvData(void *data, int maxLen) = 0;
};

class ZRTDTServer {
public:
  virtual ~ZRTDTServer() {};

  virtual int Login(void) = 0;

  virtual void LoginThread(void) = 0;
  virtual bool IsLoginSuccess(void) = 0;

  virtual void Run(void) = 0;
  virtual void Stop(void) = 0;
  virtual void ListenThread(void) = 0;

  virtual ZRTDTSession* CreateNewSession(void *data) = 0;
  virtual void DeleteSession(ZRTDTSession *session) = 0;
};

#endif /* __ZRTDT_HH__ */
