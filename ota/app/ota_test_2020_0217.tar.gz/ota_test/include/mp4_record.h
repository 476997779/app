#ifndef __MP4_RECORD_H__
#define __MP4_RECORD_H__

#include <imp/imp_common.h>
#include <imp/imp_encoder.h>

#ifdef __cplusplus
extern "C" {
#endif

// Audio Record Format
typedef enum {
	AUDIO_FORMAT_AAC = 0,
	AUDIO_FORMAT_PCM,
} MP4_AUDIO_FORMAT;

// Audio Record SampleRate
typedef enum {
	SAMPLE_RATE_8000 = 8000,
	SAMPLE_RATE_16000 = 16000,
} MP4_AUDIO_SAMPLE_RATE;

typedef struct {
	int (*get_video_frame)();
	int (*get_audio_frame)();
} mp4RecordCallback;

typedef struct {
	char	*path;		// record file path
	int64_t time_ms;    // record time (ms) 0:Stop by the mp4_record_close() function.

	/* Video Info */
	int		width;		// record video width, Consistent with H264 encoder width
	int		height;		// record video height, Consistent with H264 encoder height
	int		fps;		// record FPS, Consistent with H264 encoder FPS

	/* Audio Info */
	int		audio_en;	// audio record enable
	int		audio_fmt;	// audio record format, see enum MP4_AUDIO_FORMAT.
	int		audio_samplerate; // audio record sample rate, see enum MP4_AUDIO_SAMPLE_RATE.	
} mp4RecordInfo;

void * mp4_record_open(mp4RecordInfo *info);
void * mp4_record_append_open(mp4RecordInfo *info);
int mp4_record_enable_calllback(void * handler, mp4RecordCallback *callback);
int mp4_record_video_frame(void * handler, IMPEncoderStream *encStream);
int mp4_record_audio_frame(void * handler, unsigned char *buf, int buf_size);
int mp4_record_close(void * handler);

#ifdef __cplusplus
}
#endif

#endif // __MP4_RECODE_H__
