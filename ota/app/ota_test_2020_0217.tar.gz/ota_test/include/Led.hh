#ifndef __LED_HH__
#define __LED_HH__

void led_green_on(void);
void led_green_off(void);
int LedInit(void);

#endif /* __LED_HH__ */
