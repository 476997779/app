#ifndef __CONFIG_USER_H__
#define __CONFIG_USER_H__

#define CONFIG_ZRTDT_VERSION "Drone"
#define CONFIG_MAX_UID_LEN 32
#define CONFIG_MAX_TX_BUF_LEN (4 * 1024)
#define CONFIG_MAX_RX_BUF_LEN (32 * 1024)

#endif /* __CONFIG_USER_H__ */
