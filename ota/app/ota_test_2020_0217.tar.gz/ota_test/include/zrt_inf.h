#ifndef __ZRT_INF_H__
#define __ZRT_INF_H__

#include <ZRTDT.hh>

typedef enum {
	DT_EVENT_BIND_CAMERA = 0,
} DT_EVENT;

typedef int (*DataHandler)(ZRTDTSession *, void *, int, void *, int);
typedef const char *(*GetVersion)(void);
typedef int (*GetUID)(char *, size_t);
typedef int (*DTServerInit)(DataHandler);
typedef int (*DTServerExit)(void);
typedef int (*DTEventNotify)(int event, char *data, int size);

/* Interface function called by main program. */
extern "C"
{
const char *ZRT_INF_GetVersion(void);
int ZRT_INF_GetUID(char *uid, size_t maxLen);
int ZRT_INF_DTServerInit(DataHandler handler);
int ZRT_INF_DTServerExit(void);
int ZRT_INF_Event_Notify(int event, char *data, int size);
}

#endif /* __ZRT_INF_H__ */
