#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <net/if.h>
#include <errno.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "mp4Record.h"
#include <ZLink.h>
#include "md5.h"

#include <wy_wakeup.h>
#include <wy_tcp.h>
#include <wy_bind.h>
#include <wy_push.h>
#include <wy_debug.h>
#include <wy_test.h>
#include <wy_wlink.h>
#include <wy_file_ops.h>
#include <p2p_msg.h>

#include <AVAPIs.h>

#define WLINK_DEBUG 3
#define WLINK_UP_MSG 2
#define WLINK_RECORDER 3
#define WY_WLINK_API_DEBUG  3

#define WLINK_TEST_HEADER 0

extern "C" {
#include "ZRT_Station_Daemon.hh"
};

#include "station_p2p.h"

#define TAG "WLink"

#define MAX_SUB_CAMERA_NUM 8 /* Max Camera Number */
#define CAMERA_NAME_MAX_LEN 32
#define MAX_CLIENT_NUMBER 8 /* For P2P, Max P2P Client Number */
#define WLINK_RELAY_VIDEO_BUF_SIZE (2 *1024*1024)
#define MSG_TYPE_OTA_T30_START 0X1605
#define MSG_TYPE_OTA_T30_STAR 0X1605
typedef struct _CMD_Node {
	int type;
	char *buf;
	int size;
	struct _CMD_Node *prev;
	struct _CMD_Node *next;
} CMDNode;

enum {
    CAMERA_STATUS_UNKNOW = 0x0,
    CAMERA_STATUS_POWEROFF = 0x01,
    CAMERA_STATUS_POWERING = 0x02,
    CAMERA_STATUS_POWERON  = 0x03,
    CAMERA_STATUS_WAKEUPING = 0x04,
    CAMERA_STATUS_WAKEUP_DONE = 0x05,
    CAMERA_STATUS_RING        = 0x10,
    CAMERA_STATUS_RING_POWERON  = CAMERA_STATUS_POWERON | CAMERA_STATUS_RING,
};

typedef struct _CameraBindInfo {
    int cam_index;
    int cam_sfd;
    int wifi_ctl_sfd;
	int P2P_SID[MAX_CLIENT_NUMBER];
	int video_en_count;
	int audio_en_count;
    int record_start;
    int wakeup_source;
    int cam_status;
    int ring_status;
	void *recordHandler;
    pthread_mutex_t camera_status_mutex;
    pthread_mutex_t recorder_mutex;
	char cameraName[CAMERA_NAME_MAX_LEN];
    char recorderNmae[];
} CameraBindInfo;

typedef struct __ZLinkAVClient {
	char name[CAMERA_NAME_MAX_LEN];
	int ZLink_recordID;
	void *recordHandler;
	int record_start;
	pthread_t video_relay_thread_t;
	pthread_t audio_relay_thread_t;
	pthread_t video_record_thread_t;
	pthread_t audio_record_thread_t;
} ZLinkAVClient;

typedef struct __ZLinkHostInfo {
	int flag;
	pthread_t recv_Thread_t;
	pthread_t send_Thread_t;
	ZLinkAVClient gClientInfo[MAX_SUB_CAMERA_NUM];
} ZLinkHostInfo;

static CMDNode *g_cmd_head = NULL;
static CameraBindInfo g_CameraBindInfo[MAX_SUB_CAMERA_NUM];
static ZLinkHostInfo g_ZLinkHostInfo = {0};

enum {
    WAKEUP_FLAG_NET             = 0x01,
    WAKEUP_FLAG_PIR             = 0x02,
    WAKEUP_FLAG_KEY_RING        = 0x03,
    WAKEUP_FLAG_KEY_BIND        = 0x04,
    WAKEUP_FLAG_BAT_ALRT_N      = 0x05,
    WAKEUP_FLAG_USB_DET         = 0x06,
    WAKEUP_FLAG_CHARG_DET_N     = 0x07,
    WAKEUP_STA_BIND             = 0x08,
    WAKEUP_APP_BIND             = 0x09,
    WAKEUP_FLAG_FREMOVE         = 0x10,
    WAKEUP_FLAG_OTA             = 0x11,
};

struct wy_ota_info{
	char result;
	char o_ver[64];//升级前版本号
	char n_ver[64];//升级后版本号
};
/* 
 * 0x0 成功 
 * 0x01 电池电量低
 * 0x02 校验失败
 * 0x03 版本不对
 * 0x04 下载失败
 * */

static int Camera_Bind_FindCameraIndex(const char *cameraName);
void wy_set_ring_status(const char *cameraName, int status)
{
    int camera_index = 0;

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", cameraName);
		return;
	}
    g_CameraBindInfo[camera_index].ring_status = status;
}

int wy_get_ring_status(const char *cameraName)
{
    int camera_index = 0;

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", cameraName);
		return -1;
	}
    return g_CameraBindInfo[camera_index].ring_status;
}


static void set_camera_status(const char *name, int status)
{
    int camera_index = 0;

    camera_index = Camera_Bind_FindCameraIndex(name);
    if(camera_index < 0) {
        IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", name);
        return;
    }
    pthread_mutex_lock(&g_CameraBindInfo[camera_index].camera_status_mutex);
    g_CameraBindInfo[camera_index].cam_status = status;
    pthread_mutex_unlock(&g_CameraBindInfo[camera_index].camera_status_mutex);
}

static int get_camera_status(const char *name)
{
    int camera_index = 0;
    int status;

    camera_index = Camera_Bind_FindCameraIndex(name);
    if(camera_index < 0) {
        IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", name);
        return -1;
    }
    pthread_mutex_lock(&g_CameraBindInfo[camera_index].camera_status_mutex);
    status = g_CameraBindInfo[camera_index].cam_status;
    pthread_mutex_unlock(&g_CameraBindInfo[camera_index].camera_status_mutex);

    return status;
}

static int get_camera_status_set_poweroff(const char *name)
{
    int camera_index = 0;
    int status;

    camera_index = Camera_Bind_FindCameraIndex(name);
    if(camera_index < 0) {
        IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", name);
        return -1;
    }
    pthread_mutex_lock(&g_CameraBindInfo[camera_index].camera_status_mutex);
    status = g_CameraBindInfo[camera_index].cam_status;
    g_CameraBindInfo[camera_index].cam_status = CAMERA_STATUS_POWEROFF;
    pthread_mutex_unlock(&g_CameraBindInfo[camera_index].camera_status_mutex);

    return status;
}




void wy_set_camera_status_wakeuping(const char *name)
{
    set_camera_status(name, CAMERA_STATUS_WAKEUPING);
}

int wy_wifi_control_close_camera(const char *cameraName, int force);

/*************** Camera Bind WLink And P2P API ***** START ****************/
static int Camera_Bind_FindCameraIndex(const char *cameraName)
{
	int camera_i = 0;
	int index = -1;

	if(cameraName == NULL) {
		for(camera_i = 0; camera_i < MAX_SUB_CAMERA_NUM; camera_i++) {
			if(g_CameraBindInfo[camera_i].cameraName[0] == 0) {
				index = camera_i;
				break;
			}
		}
		return index;
	}

	for(camera_i = 0; camera_i < MAX_SUB_CAMERA_NUM; camera_i++) {

        /*
         *IMP_LOG_INFO(TAG, "g_CameraBindInfo[%d].cameraName: %s\n", camera_i, cameraName);
         */
		if(g_CameraBindInfo[camera_i].cameraName[0] &&
				(strcmp(g_CameraBindInfo[camera_i].cameraName, cameraName) == 0)) {
			index = camera_i;
			break;
		}
	}

	return index;
}

static int Camera_Bind_FindP2PIndex(int cameraIndex, int SID)
{
	int p2p_i = 0;
	int index = -1;

	if(cameraIndex >= MAX_SUB_CAMERA_NUM) {
		IMP_LOG_ERR(TAG, "Invalid camera Index\n");
		return index;
	}

	for(p2p_i = 0; p2p_i < MAX_CLIENT_NUMBER; p2p_i++) {
		if(g_CameraBindInfo[cameraIndex].P2P_SID[p2p_i] == SID) {
			index = p2p_i;
			break;
		}
	}

	return index;
}

int ZLink_Camera_Bind_UpDate(void);
static int Camera_Bind_FindCameraIndex_retry(const char *cameraName)
{
    int retry_flag = 1;
    int camera_index = -1;

INDEX_RETRY:
	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
        if(retry_flag) {
            retry_flag = 0;
            ZLink_Camera_Bind_UpDate();
            goto INDEX_RETRY;
        }
		IMP_LOG_ERR(TAG, "Camera_Bind_FindCameraIndex failed\n");
	}

    return camera_index;
}


static int get_camera_connect_phone_count(int cam_index)
{
    int i = 0;
    int count = 0;

    for(i = 0; i < MAX_CLIENT_NUMBER; i++) {
        if (g_CameraBindInfo[cam_index].P2P_SID[i] != -1) {
            count++;
        }
    }

    printf("\n\nget_camera_connect_phone_count  = %d\n\n", count);
    return count;
    return 1;
}


static void Camera_Bind_Info_Init(void)
{
	int camera_i = 0;
	int p2p_i = 0;

	memset(&g_CameraBindInfo, 0x0, sizeof(g_CameraBindInfo));

	for(camera_i = 0; camera_i < MAX_SUB_CAMERA_NUM; camera_i++) {
		g_CameraBindInfo[camera_i].wifi_ctl_sfd = -1;
		g_CameraBindInfo[camera_i].cam_sfd = -1;
		g_CameraBindInfo[camera_i].cam_index    = -1;

		for(p2p_i = 0; p2p_i < MAX_CLIENT_NUMBER; p2p_i++) {
			g_CameraBindInfo[camera_i].P2P_SID[p2p_i] = -1;
		}
	}
}

static int Camera_Bind_With_P2P(char *cameraName, int SID)
{
	int camera_index = 0;
	int p2p_index = 0;

	IMP_LOG_INFO(TAG, "%s %d: %s %d\n",__func__, __LINE__, cameraName, SID);

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", cameraName);
		return -1;
	}

	p2p_index = Camera_Bind_FindP2PIndex(camera_index, SID);
	if(p2p_index < 0) {
		p2p_index = Camera_Bind_FindP2PIndex(camera_index, -1);
		if(p2p_index < 0) {
			IMP_LOG_ERR(TAG, "P2P Bind Camera have reached the maximum");
			return -1;
		}

		g_CameraBindInfo[camera_index].P2P_SID[p2p_index] = SID;
	}

	return 0;
}

static int Camera_UnBind_With_P2P(char *cameraName, int SID)
{
	int camera_index = 0;
	int p2p_index = 0;

	IMP_LOG_INFO(TAG, "%s %d: %s %d\n",__func__, __LINE__, cameraName, SID);

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", cameraName);
		return -1;
	}

	p2p_index = Camera_Bind_FindP2PIndex(camera_index, SID);
	if(p2p_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s) SID (%d)\n", cameraName, SID);
	} else {
		g_CameraBindInfo[camera_index].P2P_SID[p2p_index] = -1;
	}

	return 0;
}

static int Camera_Bind_With_Cam_Id(char *cameraName, int cam_sfd)
{
	int camera_index = 0;

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", cameraName);
		return -1;
	}

	g_CameraBindInfo[camera_index].cam_sfd = cam_sfd;
	g_CameraBindInfo[camera_index].cam_index = camera_index;

	return camera_index;
}

static int Camera_Bind_With_Wifi_Ctl_Id(char *cameraName, int wifi_ctl_sfd)
{
	int camera_index = 0;

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", cameraName);
		return -1;
	}

	g_CameraBindInfo[camera_index].wifi_ctl_sfd = wifi_ctl_sfd;

	return 0;
}

static int Camera_BindInfo_Add_Camera(char *cameraName)
{
	int camera_index = 0;

	if(cameraName == NULL) {
		IMP_LOG_ERR(TAG, "Invalid Camera Name\n");
		return -1;
	}

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		camera_index = Camera_Bind_FindCameraIndex(NULL);
		if(camera_index < 0) {
			IMP_LOG_ERR(TAG, "Camera have reached the maximum\n");
			return -1;
		}

		strncpy(g_CameraBindInfo[camera_index].cameraName, cameraName, CAMERA_NAME_MAX_LEN - 1);
	}

	return 0;
}

#if 0
static int Camera_BindInfo_Del_Camera(char *cameraName)
{
	int camera_index = 0;

	if(cameraName == NULL) {
		IMP_LOG_ERR(TAG, "Invalid Camera Name\n");
		return -1;
	}

	camera_index = Camera_Bind_FindCameraIndex(cameraName);
	if(camera_index < 0) {
		IMP_LOG_ERR(TAG, "Can't find camera (%s)\n", cameraName);
		return -1;
	}

	memset(g_CameraBindInfo[camera_index].cameraName, 0x0, CAMERA_NAME_MAX_LEN);
	return 0;
}
#endif

/*************** Camera Bind ZLink And P2P API ***** END ****************/

/*************** Camera Event API ***** START ****************/
static int Camera_Event_Notify(char *cameraName, int event, char *data, int size)
{
	if(g_P2PCustomFunc.P2P_Custom_Event) {
		g_P2PCustomFunc.P2P_Custom_Event(cameraName, event, data, size);
	}

	return 0;
}

/*************** Camera Event API ***** END *****************/

/*************** ZLink Logic API *** START **************/
static pthread_mutex_t cmd_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cmd_cond = PTHREAD_COND_INITIALIZER;
static pthread_mutex_t g_queue_mutex = PTHREAD_MUTEX_INITIALIZER;
static void ZLink_CMD_Wait_Time(int time_ms)
{
	struct timeval now;
	struct timespec timeout;

	pthread_mutex_lock(&cmd_mutex);
	gettimeofday(&now, NULL);
	timeout.tv_sec = now.tv_sec + time_ms / 1000;

	if((now.tv_usec / 1000) + (time_ms % 1000) > 1000) {
		timeout.tv_sec += 1;
	}
	timeout.tv_nsec = ((now.tv_usec + (time_ms % 1000) * 1000) % 1000000) * 1000;

	if(pthread_cond_timedwait(&cmd_cond, &cmd_mutex, &timeout) == ETIMEDOUT)
		IMP_LOG_WARN(TAG, "CMD Wait timeout\n");
	pthread_mutex_unlock(&cmd_mutex);
}

static void ZLink_CMD_Post()
{
	pthread_mutex_lock(&cmd_mutex);
	pthread_cond_signal(&cmd_cond);
	pthread_mutex_unlock(&cmd_mutex);
}

static int ZLink_CMD_Queue_Push(int type, char *buf, int size)
{
	pthread_mutex_lock(&g_queue_mutex);
	CMDNode *node = (CMDNode *)malloc(sizeof(CMDNode));
	if(node == NULL) {
		IMP_LOG_ERR(TAG, "ZLink_CMD_Queue_Push malloc node error\n");
        pthread_mutex_unlock(&g_queue_mutex);
		return -1;
	}

	node->buf = (char *)malloc(size);
	if(node->buf == NULL) {
		IMP_LOG_ERR(TAG, "ZLink_CMD_Queue_Push malloc node->buf error, size = %d\n", size);
        pthread_mutex_unlock(&g_queue_mutex);
		return -1;
	}

	memcpy(node->buf, buf, size);
	node->type = type;
	node->size = size;
	node->prev = NULL;
	node->next = NULL;

	if(g_cmd_head == NULL) {
		g_cmd_head = node;
	} else {
		CMDNode *node_t = g_cmd_head;
		while(1) {
			if(node_t->next == NULL) {
				node_t->next = node;
				node->prev = node_t;
				break;
			}
			node_t = node_t->next;
		}
	}

    pthread_mutex_unlock(&g_queue_mutex);
	ZLink_CMD_Post();
	return 0;
}

struct wheader {
    char header[4];     // 2 字节， 标志包的开始
    uint16_t cmd;
    uint16_t flag;          // video is I or P frame
    uint32_t dlen;      // dlen == 0,no data
    uint32_t seq;
    uint64_t timestamp;
    uint64_t reserve;
};
static int ZLink_CMD_Queue_Pop(int type, char *buf, int maxSize)
{
	CMDNode *node_t = g_cmd_head;
	int data_size = 0;

	int i;
    
	struct wheader *pack_ret = NULL;

    pthread_mutex_lock(&g_queue_mutex);
	while(1) {
		if(node_t == NULL) {
			//IMP_LOG_ERR(TAG, "type(%x) is not find\n", type);
            pthread_mutex_unlock(&g_queue_mutex);
			return -1;
		}

		//IMP_LOG_INFO(TAG, "List Type = %x type = %x\n", node_t->type, type);

		printf("type = 0x%xH \n",type);
		if(node_t->type == type) {
			
			printf("node_buf\n");
			for (i = 0; i < 32; i++) {
				printf("%02x ", (unsigned char)node_t->buf[i]);
		    }
			printf("\n");
			
    	//	pack_ret = (struct wheader *)(node_t->buf);

		//	printf("raw data is %d\n",pack_ret->flag);

			memcpy(buf, node_t->buf, (node_t->size < maxSize) ? node_t->size : maxSize);
			data_size = node_t->size;

			printf("buf\n");
			for (i = 0; i < 32; i++) {
				printf("%02x ", (unsigned char)buf[i]);
		    }
			printf("\n");
		
			if(node_t == g_cmd_head) {
				g_cmd_head = NULL;
			} else if(node_t->next) {
				node_t->prev->next = node_t->next;
				node_t->next->prev = node_t->prev;
			} else {
				node_t->prev->next = NULL;
			}

			free(node_t->buf);
			free(node_t);
			break;
		}

		node_t = node_t->next;
	}

    pthread_mutex_unlock(&g_queue_mutex);
	return data_size;
}

static int ZLink_CMD_Queue_Pop_Timeout(const char *name, int type, char *buf, int maxSize, int time_ms)
{
	int ret = 0;

    int count = time_ms / 500;
    unsigned int i = 0;

    for (i = 0; i < 6553666; i++) {
    //for (i = 0; i < count; i++) {
        ret = ZLink_CMD_Queue_Pop(type, buf, maxSize);
        if (ret >= 0) {
            break;
        }
        ZLink_CMD_Wait_Time(500);
        if (get_camera_status(name) == CAMERA_STATUS_POWEROFF) {
            printf("POWER OFF, %s\n", __func__);
			ret = -1;
            break;
        }
    }
	if(i < 6553666){
		printf("recv CMD:%x data\n", type);
	}else	
		printf("i = 6553666 time out \n ");

	if(ret < 0) {
		IMP_LOG_ERR(TAG, "Don't recv CMD:%x data\n", type);
	}

	return ret;
}

enum {
    WLINK_PACK_HEADER1 = 0x57,
    WLINK_PACK_HEADER2 = 0x59,
};

enum {
    // down cmds, 大部分直接透传给 camera
    WLINK_VIDEO_START               = 0x0000,              /*<video 启动>*/
    WLINK_VIDEO_STOP,                                 /*<video 停止>*/
    WLINK_VIDEO_REQUEST_IDR,                          /*<video 请求I帧>*/
    WLINK_AUDIO_START,                                /*<audio 启动>*/
    WLINK_AUDIO_STOP,                                 /*<audio 停止>*/
    WLINK_AUDIO_SPK_START,                          /*<audio 对讲启动>*/
    WLINK_AUDIO_SPK_STOP,                           /*<audio 对讲停止>*/
    WLINK_MP4_RECORD_START,                         /*<audio> mp4录像启动*/
    WLINK_MP4_RECORD_STOP,                          /*<audio> mp4录像停止*/
    WLINK_CLIENT_CLOSE              = 0x0009,         /*client 关闭, DA16200 处理*/

    // up cmds
    WLINK_CAMERA_READY              = 0x0060,   // DA16200 处理

    WLINK_CMD_VIDEO_DATA            = 0x0080,   // DA16200 透传
    WLINK_CMD_AUDIO_DATA            = 0x0081,
    WLINK_CMD_RECODER_VIDEO_DATA    = 0x0082,
    WLINK_CMD_RECODER_AUDIO_DATA    = 0x0083,

};

enum {
    WIFI_CTRL_CLIENT_CLOSE                      = 0x09,
    WIFI_CTRL_CLOSE_SESSION                     = 0x2000,
    WIFI_CTRL_REPORT_WAKEUPSOURCE               = 0x3100,
    WIFI_CTRL_PUSH_MSG                          = 0x5000,
    WIFI_CTRL_CAMERA_WAKEUP                     = 0x6000,
    WIFI_CTRL_WAKEUP_DONE                       = 0x6001,
    WIFI_CTRL_APP_BIND_DATA                     = 0x7000,
    WIFI_CTRL_STA_BIND_DATA                     = 0x8000,
    WIFI_CTRL_POWER_GET_PIR                     = 0x1400,
    WIFI_CTRL_POWER_SET_PIR                     = 0x1401,
    WIFI_CTRL_GET_DEV_INFO                      = 0x1200,
    WIFI_CTRL_GET_FREMOVE                       = 0x1500,
    WIFI_CTRL_SET_FREMOVE                       = 0x1501,

};


#pragma pack(1)

#define HEADER_PACK_LEN  32
#pragma pack()

#define RED_COLOR               "\33[1;31m"
#define GREEN_COLOR             "\33[1;32m"
#define YELLOW_COLOR            "\33[1;33m"
static int socket_recv_fix_data_len(int socket_fd, char *rbuf, uint32_t len)
{
    int nread = 0;
    uint32_t nleft = len;
    unsigned char *ptr = (unsigned char *)rbuf;

    //wy_info(WLINK_DEBUG, "p read sfd = %d, len = %d\n", socket_fd, len);
    while (nleft > 0) {
        nread = recv(socket_fd, ptr, nleft, 0);
        if (nread < 0) {
            printf(RED_COLOR"client may close, errno = %s\n"RED_COLOR, strerror(errno));
            printf(RED_COLOR"len = %d, nleft = %d, ptr = %p\n"RED_COLOR, len, nleft, ptr);
            return -1;
        }
        if (nread == 0) {
            printf(RED_COLOR"nread = %d:\n"RED_COLOR, nread);
            return -1;
        }
#if 0
        //wy_info(WLINK_UP_MSG, "socket_fd: %d, nread = %d:\n", socket_fd, nread);
        //printf(YELLOW_COLOR);

        if (len == 32) {
            wy_hexdump(WLINK_DEBUG, GREEN_COLOR"recv", ptr, 6);
            //wy_info(WLINK_DEBUG, "socket fd = %d\n"GREEN_COLOR, socket_fd);
        }
#endif
        nleft -= nread;
        ptr   += nread;
    }

    return 0;
}

static int find_whole_pack_header(int cam_sfd, uint8_t *rbuf, int len) 
{
    int i = 0;  
    int find = 0;  
    int ret = 0;  
    uint8_t tmp[HEADER_PACK_LEN *2]; 
    uint8_t tmp2[HEADER_PACK_LEN];

    if (len != HEADER_PACK_LEN) {
        return -1; 
    }   

retry:
    memcpy(tmp, rbuf, HEADER_PACK_LEN);
    for (i = 0; i < (len - 1); i++) {
        if ((tmp[i] != WLINK_PACK_HEADER1) || (tmp[i + 1] != WLINK_PACK_HEADER2)) {
            continue;
        }        
        find = 1;  
        break;
    }        
    if (1 == find) {
        memcpy(tmp2, rbuf + i, HEADER_PACK_LEN - i); 
        ret = socket_recv_fix_data_len(cam_sfd, (char*)tmp2 + HEADER_PACK_LEN - i, i); 
        memcpy(rbuf, tmp2, HEADER_PACK_LEN);

        return ret; 
    } else {
        rbuf[0] = tmp[HEADER_PACK_LEN - 1]; 
        ret = socket_recv_fix_data_len(cam_sfd, (char*)rbuf + 1, HEADER_PACK_LEN - 1); 
        if (ret != 0) { 
            return -1; 
        }   

#if WLINK_TEST_HEADER
        wy_hexdump(WLINK_DEBUG, "header2:", rbuf, HEADER_PACK_LEN);
        while(1);
#endif

        goto retry;
    }   

    return 0;
}

static int socket_recv_one_pack(int cam_sfd, char * const rbuf)
{
    int ret = socket_recv_fix_data_len(cam_sfd, rbuf, HEADER_PACK_LEN);
    if (ret != 0) {
        return -1;
    }
    if ((rbuf[0] != WLINK_PACK_HEADER1) || (rbuf[1] != WLINK_PACK_HEADER2)) {
        wy_error(WLINK_DEBUG, "error header\n");
        wy_hexdump(WLINK_DEBUG, "header", (unsigned char*)rbuf, HEADER_PACK_LEN);
        ret = find_whole_pack_header(cam_sfd, (uint8_t *)rbuf, HEADER_PACK_LEN);
        if (ret < 0) {
            return ret;
        }
    }

    struct wheader *pack = (struct wheader *)rbuf;
    uint32_t dlen = ntohl(pack->dlen);
    wy_info(WLINK_UP_MSG,"seq: %d cmd = 0x%04x, %d ========pack dlen = %08x,  %d .......", ntohl(pack->seq), ntohs(pack->cmd), ntohs(pack->cmd),dlen, dlen);
    if (dlen != 0) {
        if (dlen > 1024 * 1024) {
            wy_error(WLINK_UP_MSG," ===================================\n");
            wy_error(WLINK_UP_MSG," dlen is %d\n", dlen);
            wy_error(WLINK_UP_MSG," dlen is %d\n", dlen);
            wy_error(WLINK_UP_MSG," dlen is %d\n", dlen);
            wy_error(WLINK_UP_MSG," dlen is %d\n", dlen);
            wy_error(WLINK_UP_MSG," dlen is %d\n", dlen);
            wy_error(WLINK_UP_MSG," dlen is %d\n", dlen);
            wy_error(WLINK_UP_MSG," ===================================\n");
            sleep(100);

        } else {
            ret = socket_recv_fix_data_len(cam_sfd, rbuf + HEADER_PACK_LEN, dlen); 
        }
    }

    return ret;
}

#if 0
typedef union {
    uint64_t val;
    struct {
        uint32_t h;
        uint32_t l;
    }st64;
}convert64_t;

static uint64_t ntoh_64(uint64_t val)                                                                                                                                                                              
{
    convert64_t v, tmp;
    v.val = val;
    tmp.st64.h = htonl(v.st64.l);
    tmp.st64.l = htonl(v.st64.h);

    return tmp.val;
}
#endif

static int send_video_data_to_phone(CameraBindInfo *camBInfo, struct wheader *pack, char *rbuf)
{
    int i;

    if (NULL == g_P2PCustomFunc.P2P_Custom_Send_Video_Frame) {
        return 0;
    }
    for(i = 0; i < MAX_CLIENT_NUMBER; i++) {
        if(camBInfo->P2P_SID[i] < 0) {
            continue;
        }
#if 0
        printf("video data: flag: %u(0x%x), seq: %u(0x%x), timestamp:%llu(0x%llx)\n", \
               ntohs(pack->flag), ntohs(pack->flag), \
               ntohl(pack->seq), ntohl(pack->seq),\
               ntoh_64(pack->timestamp), ntoh_64(pack->timestamp));
#endif
        fprintf(stderr, ".");

        g_P2PCustomFunc.P2P_Custom_Send_Video_Frame(camBInfo->P2P_SID[i],
                                                    (uint8_t *)rbuf, 
                                                    ntohl(pack->dlen), 
                                                    ntohs(pack->flag),
                                                    ntohl(pack->seq),
                                                    pack->timestamp);
    }

    return 0;
}

static int send_audio_data_to_phone(CameraBindInfo *camBInfo, struct wheader *pack, char *rbuf)
{
    int i;

    if (NULL == g_P2PCustomFunc.P2P_Custom_Send_Audio_Frame) {
        return 0;
    }
    for(i = 0; i < MAX_CLIENT_NUMBER; i++) {
        if(camBInfo->P2P_SID[i] < 0) {
            continue;
        }
        wy_info(WLINK_UP_MSG,"audio data: timestamp %llu, camBInfo->P2P_SID[i] = %d\n", pack->timestamp, camBInfo->P2P_SID[i]);
        g_P2PCustomFunc.P2P_Custom_Send_Audio_Frame(camBInfo->P2P_SID[i],
                                                    (uint8_t *)rbuf, 
                                                    ntohl(pack->dlen), 
                                                    pack->timestamp);
    }
    return 0;
}

static int get_recorder_status_locked(CameraBindInfo *camBInfo)
{
    int record_start;
    pthread_mutex_lock(&camBInfo->recorder_mutex);
    record_start = camBInfo->record_start;
    pthread_mutex_unlock(&camBInfo->recorder_mutex);

    return record_start;
}

static int get_recorder_status_and_clear_locked(CameraBindInfo *camBInfo)
{
    int record_start;
    pthread_mutex_lock(&camBInfo->recorder_mutex);
    record_start = camBInfo->record_start;
    camBInfo->record_start = 0;
    pthread_mutex_unlock(&camBInfo->recorder_mutex);

    return record_start;
}

#if 0
static int get_recorder_status_set_locked(CameraBindInfo *camBInfo)
{
    int record_start;
    pthread_mutex_lock(&camBInfo->recorder_mutex);
    record_start = camBInfo->record_start;
    camBInfo->record_start = 1;
    pthread_mutex_unlock(&camBInfo->recorder_mutex);

    return record_start;
}
#endif

static void set_recorder_status_locked(CameraBindInfo *camBInfo, int status)
{
    pthread_mutex_lock(&camBInfo->recorder_mutex);
    camBInfo->record_start = status;
    pthread_mutex_unlock(&camBInfo->recorder_mutex);
}

static void recorder_start(CameraBindInfo *camBInfo, char *rbuf)
{
    if (get_recorder_status_locked(camBInfo) != 1) {
        wy_info(WLINK_RECORDER, "ZLINK_MP4_RECORD_START\n");
        wy_delete_file(MP4_RECORD_PATH_CONFIG);
        ZLink_RecordInfo *RecordInfo = (ZLink_RecordInfo *)(rbuf + HEADER_PACK_LEN);
        camBInfo->recordHandler = ZRT_Mp4Record_Create(camBInfo->cameraName,
                                                       RecordInfo->name, RecordInfo->width, RecordInfo->height, RecordInfo->fps);
        set_recorder_status_locked(camBInfo, 1);

        wy_info(WLINK_RECORDER, "MP4 Record Start: %s W:%d H:%d FPS:%d\n", RecordInfo->name, RecordInfo->width, RecordInfo->height, RecordInfo->fps);
    }
}

static void recorder_stop(CameraBindInfo *camBInfo, int force)
{
    if (get_recorder_status_and_clear_locked(camBInfo) != 0) {
        wy_info(WLINK_RECORDER, "ZLINK_MP4_RECORD_STOP\n");
        char *recorder_name = ZRT_Mp4Record_Stop(camBInfo->cameraName, camBInfo->recordHandler);
        camBInfo->recordHandler = NULL;


        if (recorder_name != NULL) {
            if (force) {
                wy_info(WLINK_RECORDER, "ZLINK_MP4_RECORD_STOP force not send\n");
                if (!wy_check_sdcard()) {
                    wy_delete_file(recorder_name);
                }
                return;
            }

            int flag = 0x1;

            if (WAKEUP_FLAG_KEY_RING == camBInfo->wakeup_source) {
                flag = WY_MSG_FLAG_VIDEO_RING;
            } else if (WAKEUP_FLAG_PIR == camBInfo->wakeup_source) {
                flag = WY_MSG_FLAG_VIDEO_PIR;
            } else if (WAKEUP_FLAG_FREMOVE == camBInfo->wakeup_source) {
                flag = WY_MSG_FLAG_VIDEO_FREMOVE;
            } else {
                printf("not support wakeup flag: 0x%x\n", camBInfo->wakeup_source);
            }

            wy_push_msg_queue_add_msg(flag, 10 * 1000, camBInfo->cameraName, recorder_name);
        } else {
            wy_info(WLINK_RECORDER,"recorder_name is NULL\n");
        }
    }
}

static void *WLink_Cam_Data_Thread(void *cam_bind_info)
{
    pthread_detach(pthread_self());
    CameraBindInfo *camBInfo = (CameraBindInfo *)cam_bind_info;
	int cam_sfd = (int)camBInfo->cam_sfd;
    char * const rbuf = (char *)malloc(WLINK_RELAY_VIDEO_BUF_SIZE);
    if (NULL == rbuf) {
        IMP_LOG_ERR(TAG, "malloc rbuf failed\n");
        return NULL;
    }
    camBInfo->record_start = 0;
    pthread_mutex_init(&camBInfo->recorder_mutex, NULL);
    pthread_mutex_init(&camBInfo->camera_status_mutex, NULL);
    camBInfo->cam_status = CAMERA_STATUS_UNKNOW;
    struct wheader *pack = (struct wheader *)rbuf;
    usleep(200000);
	Camera_Event_Notify(camBInfo->cameraName, EVENT_CAMERA_ZLINK_ONLINE, NULL, 0);
    wy_info(WLINK_DEBUG,"cam data rbuf = %p-----------------------------\n", rbuf);

#ifdef WLINK_TEST_THREAD
    void *test_thread_func(void *cam_name);
	pthread_t test_Thread_t;
    pthread_create(&test_Thread_t, NULL, 
                   test_thread_func, 
                   (void *)camBInfo->cameraName);
#endif

    while (1) {
        if (socket_recv_one_pack(cam_sfd, rbuf) < 0) {
            //fix how to do ?
            printf("socket_recv_head failed, %s\n", __func__);
            Camera_Bind_With_Cam_Id(camBInfo->cameraName, -8);
            close(cam_sfd);
            free(rbuf);
            wy_reboot_remote_wifi_module_by_uuid(camBInfo->cameraName);
            break;
        }

#ifdef WLINK_TEST
        if (0xffff == pack->cmd) {
            test_start_send(cam_bind_info);
            continue;
        }

        int ret = test_check_pack((uint8_t *)rbuf, HEADER_PACK_LEN + ntohl(pack->dlen));    
        if (ret < 0) {
            break;
        }
        continue;
#endif

        uint16_t cmd = ntohs(pack->cmd);
        if (get_camera_status(camBInfo->cameraName) == CAMERA_STATUS_POWEROFF) {
            wy_info(WLINK_UP_MSG,"power off do  pack->cmd = 0x%04x, 0x%04x\n", pack->cmd, ntohs(pack->cmd));
            continue;
        }
        wy_info(WLINK_UP_MSG,"do  pack->cmd = 0x%04x, 0x%04x\n", pack->cmd, ntohs(pack->cmd));

        switch (cmd) {
        case WLINK_CMD_VIDEO_DATA:
            send_video_data_to_phone(camBInfo, pack, rbuf + HEADER_PACK_LEN);
            break;

        case WLINK_CMD_AUDIO_DATA:
            send_audio_data_to_phone(camBInfo, pack, rbuf + HEADER_PACK_LEN);
            break;

        case WLINK_CMD_RECODER_VIDEO_DATA:
            if (get_recorder_status_locked(camBInfo) == 1) {
                ZRT_Mp4Record_SaveVideo(camBInfo->recordHandler,
                                        (unsigned char *)rbuf + HEADER_PACK_LEN, ntohl(pack->dlen), pack->flag);
            } else {
                wy_info(WLINK_DEBUG,"recorder not start\n");
            }
            break;
        case WLINK_CMD_RECODER_AUDIO_DATA:
            if (get_recorder_status_locked(camBInfo) == 1) {
                ZRT_Mp4Record_SaveAudio(camBInfo->recordHandler,
                                        (unsigned char *)rbuf + HEADER_PACK_LEN, ntohl(pack->dlen));
            } else {
                wy_info(WLINK_DEBUG,"recorder not start\n");
            }
            break;

		case ZLINK_MP4_RECORD_START:
            recorder_start(camBInfo, rbuf);
            break;

		case ZLINK_MP4_RECORD_STOP:
            recorder_stop(camBInfo, 0);
            //if ((camBInfo->video_en_count == 0x0) || (camBInfo->ring_status != RING_STAT_ANSWERED)) {
            if (camBInfo->ring_status != RING_STAT_ANSWERED) {
                wy_wifi_control_close_camera(camBInfo->cameraName, 1);
            }
            wy_info(WLINK_RECORDER, "MP4 Record Stop, camBInfo->video_en_count = 0x%x\n", camBInfo->video_en_count);
            break;

        case WIFI_CTRL_APP_BIND_DATA:
            parse_qrcode_and_run((const char *)(rbuf + HEADER_PACK_LEN), ntohl(pack->dlen));
            break;

        default:
            // 处理 RESP
            wy_info(WLINK_DEBUG,"default pack->cmd = 0x%04x\n", cmd);
			ZLink_CMD_Queue_Push(cmd, rbuf + HEADER_PACK_LEN, ntohl(pack->dlen));
            break;
        }
    }

    return NULL;
}

static void *WLink_Wifi_Data_Thread(void *cam_bind_info)
{
    pthread_detach(pthread_self());
    CameraBindInfo *camBInfo = (CameraBindInfo *)cam_bind_info;
	int wifi_ctl_sfd = (int)camBInfo->wifi_ctl_sfd;
    char * const rbuf = (char *)malloc(WLINK_RELAY_VIDEO_BUF_SIZE);
    if (NULL == rbuf) {
        IMP_LOG_ERR(TAG, "malloc rbuf failed\n");
        return NULL;
    }
    struct wheader *pack = (struct wheader *)rbuf;
    wy_info(WLINK_DEBUG,"WLink_Wifi_Data_Thread startted rbuf = %p-----------------------------\n", rbuf);
    while (1) {
        if (socket_recv_one_pack(wifi_ctl_sfd, rbuf) < 0) {
            //fix how to do ?
            printf("socket_recv_head failed, %s\n", __func__);
            Camera_Bind_With_Wifi_Ctl_Id(camBInfo->cameraName, -8);
            close(wifi_ctl_sfd);
            free(rbuf);
            wy_reboot_remote_wifi_module_by_uuid(camBInfo->cameraName);
            break;
        }

        uint16_t cmd = ntohs(pack->cmd);
        wy_info(WLINK_DEBUG,"do  pack->cmd = 0x%04x, 0x%04x\n", pack->cmd, ntohs(pack->cmd));
        switch (cmd) {
        case WIFI_CTRL_PUSH_MSG:
            if (get_camera_status(camBInfo->cameraName) != CAMERA_STATUS_RING_POWERON) {
                set_camera_status(camBInfo->cameraName, CAMERA_STATUS_RING_POWERON);
                wy_push_msg((unsigned char *)rbuf + HEADER_PACK_LEN, ntohl(pack->dlen), WY_PUSH_NORMAL_MSG_TCP_PORT);
            } else {
                wy_info(WLINK_DEBUG,"in ring mode\n");
            }
            break;

        case WIFI_CTRL_WAKEUP_DONE:
            set_camera_status(camBInfo->cameraName, CAMERA_STATUS_WAKEUP_DONE);
            notify_wakeup_done();
            break;
        case WIFI_CTRL_REPORT_WAKEUPSOURCE:
            set_camera_status(camBInfo->cameraName, CAMERA_STATUS_POWERON);
            camBInfo->wakeup_source = ntohs(pack->flag);
            if (WAKEUP_FLAG_KEY_RING == camBInfo->wakeup_source) {
                camBInfo->ring_status = RING_STAT_UNKNOW;
            }

            break;
        default:
            // 处理 RESP
            wy_info(WLINK_DEBUG,"wifi default pack->cmd = 0x%04x\n", cmd);
			ZLink_CMD_Queue_Push(cmd, rbuf + HEADER_PACK_LEN, ntohl(pack->dlen));
            break;
        }
    }

    return NULL;
}



static int WLink_Get_CameraName_By_IP(char *cameraName, int maxSize, char *IP)
{
    ZRT_Camera cams[MAX_SUB_CAMERA_NUM];
    int num = 0;
	int i = 0;

	if(cameraName == NULL || IP == NULL) {
        IMP_LOG_ERR(TAG, "WLink_Get_CameraName_By_IP cameraName or IP is NULL\n");
        return -1;
	}

	num = ZRT_STA_GetCameras(cams, MAX_SUB_CAMERA_NUM);
    if (num < 0) {
        IMP_LOG_ERR(TAG, "%s: ZRT_STA_GetCameras error\n", __func__);
        return -1;
    }

    for(i = 0; i < num; i++) {
		IMP_LOG_INFO(TAG, "IP = %s cams.IP = %s cams.MAC = %s cams.Name = %s\n", IP, cams[i].ip, cams[i].mac, cams[i].uid);
		if(strcmp(IP, cams[i].ip) == 0) {
			strncpy(cameraName, cams[i].uid, maxSize);
			break;
		}
    }

	return 0;
}

void *WLink_Camera_Connect_Server(void *args)
{
    int ret = 0;
    pthread_detach(pthread_self());
    SET_THREAD_NAME("Up_Data_Thread");
    int listenfd = 0, cam_sfd;
    struct sockaddr_in cliaddr;

    listenfd = tcp_listen(9999);
    if (listenfd < 0) {
        return NULL;
    }

    while (1) {
        int  SID = 0; // 这里需要考虑 camera 断电的情况 fix
		char cameraName[32] = "";
        socklen_t clilen = (socklen_t)sizeof(struct sockaddr);
        wy_info(WLINK_DEBUG,"=================================%s,   start\n", __func__);
        if ((cam_sfd = accept(listenfd, (struct sockaddr *)&cliaddr, &clilen)) < 0 ) {
            if (errno == EINTR) {
                continue;       /* back to for() */
            } else {
                IMP_LOG_ERR(TAG, "%s accept error", __func__);
                return NULL;
            }
        } else {
            ZLink_Camera_Bind_UpDate();
            wy_info(WLINK_DEBUG,"%s,   connect, cam_sfd: %d\n", __func__, cam_sfd);
            char *peer_ip = inet_ntoa(cliaddr.sin_addr);
            ret = WLink_Get_CameraName_By_IP(cameraName, sizeof(cameraName), peer_ip);
            if(ret < 0) {
                IMP_LOG_ERR(TAG, "WLink_Get_CameraName_By_IP error: %d IP:%s\n", ret, peer_ip);
                continue;
            }
            strncpy(g_ZLinkHostInfo.gClientInfo[SID].name, cameraName, CAMERA_NAME_MAX_LEN);

            int cam_index = Camera_Bind_With_Cam_Id(cameraName, cam_sfd);
            if(cam_index < 0) {
                IMP_LOG_ERR(TAG, "Camera_Bind_With_ZLink error: %d \n", cam_index);
                continue;
            }

            pthread_create(&g_ZLinkHostInfo.recv_Thread_t, NULL, 
                           WLink_Cam_Data_Thread, 
                           (void *)&g_CameraBindInfo[cam_index]);
        }
    }
}


void *WLink_Wifi_Ctl_Server(void *args)
{
    int ret = 0;
    pthread_detach(pthread_self());
    SET_THREAD_NAME("Down_Data_Thread");
    int listenfd = 0, wifi_ctl_sfd;
    struct sockaddr_in cliaddr;

    listenfd = tcp_listen(5555);
    if (listenfd < 0) {
        return NULL;
    }

    while (1) {
        //int  SID = 0; // 这里需要考虑 camera 断电的情况 fix
		char cameraName[32] = "";
        socklen_t clilen = (socklen_t)sizeof(struct sockaddr);
        wy_info(WLINK_DEBUG,"==============================%s,   start\n", __func__);
        if ((wifi_ctl_sfd = accept(listenfd, (struct sockaddr *)&cliaddr, &clilen)) < 0 ) {
            if (errno == EINTR) {
                continue;       /* back to for() */
            } else {
                IMP_LOG_ERR(TAG, "%s accept error", __func__);
                return NULL;
            }
        } else {
            wy_info(WLINK_DEBUG,"%s,   connect %d\n", __func__, wifi_ctl_sfd);
            ZLink_Camera_Bind_UpDate();
            char *peer_ip = inet_ntoa(cliaddr.sin_addr);
            ret = WLink_Get_CameraName_By_IP(cameraName, sizeof(cameraName), peer_ip);
            if(ret < 0) {
                IMP_LOG_ERR(TAG, "WLink_Get_CameraName_By_IP error: %d IP:%s\n", ret, peer_ip);
                continue;
            }

            ret = Camera_Bind_With_Wifi_Ctl_Id(cameraName, wifi_ctl_sfd);
            if(ret < 0) {
                IMP_LOG_ERR(TAG, "Camera_Bind_With_Wifi_Ctl_Id error: %d \n", ret);
                continue;
            }

            int cam_index = Camera_Bind_FindCameraIndex_retry(cameraName);
            if (cam_index < 0) {
                printf("%s:%d, error\n", __func__, __LINE__);
                continue;
            }

            pthread_create(&g_ZLinkHostInfo.send_Thread_t, NULL, 
                           WLink_Wifi_Data_Thread, 
                           (void *)&g_CameraBindInfo[cam_index]);
        }
    }
}


/*************** ZLink Logic API *** END **************/
static void wlink_fill_header_pack(struct wheader *pack, uint16_t cmd, uint32_t dlen, uint16_t flag)
{
    wy_info(WLINK_DEBUG,"--------> cmd: %d: 0x%x, dlen: %d, 0x%x\n", cmd, cmd, dlen, dlen);
    pack->header[0] = WLINK_PACK_HEADER1;
    pack->header[1] = WLINK_PACK_HEADER2;
    pack->cmd    = htons(cmd);
    pack->dlen   = htonl(dlen);
    pack->flag   = htonl(flag);
}

static int send_pack(int cam_sfd, uint16_t cmd, char *data, uint32_t dlen,  uint16_t flag)
{
    char *sbuf = NULL;
    sbuf = (char*)malloc(dlen + HEADER_PACK_LEN);
    if (NULL == sbuf) {
        printf("can not alloc buf len : %d\n", dlen + HEADER_PACK_LEN);
        return -1;
    }    
    memset(sbuf, 0, dlen + HEADER_PACK_LEN);

    wlink_fill_header_pack((struct wheader *)sbuf, cmd, dlen, flag);
    if (dlen > 0) { 
        memcpy(sbuf + HEADER_PACK_LEN, data, dlen);
    }

    int ret = send(cam_sfd, sbuf, dlen + HEADER_PACK_LEN, 0);
    free(sbuf);

    return ret; 
}

int ZLink_Camera_Bind_UpDate(void)
{
    ZRT_Camera cams[MAX_SUB_CAMERA_NUM];
    int num = 0;
	int i = 0;

    wy_info(WLINK_DEBUG,"========================%s:%d\n", __func__, __LINE__);
	num = ZRT_STA_GetCameras(cams, MAX_SUB_CAMERA_NUM);
    if (num < 0) {
        IMP_LOG_ERR("%s: ZRT_STA_GetCameras error\n", __func__);
        return -1;
    }

    for(i = 0; i < num; i++) {
		Camera_BindInfo_Add_Camera(cams[i].uid);
    }

	return num;
}

int WLink_Cam_Control(const char *cameraName, uint16_t cmd, char *data, uint32_t dlen, uint16_t flag)
{
    int ret = 0; 
/*
    wy_info(WLINK_DEBUG,"camera_name: %s\n", camera_name);
    int cam_sfd = wy_camera_get_camera_socket_fd_by_name(camera_name);
    if (cam_sfd < 0) { 
        IMP_LOG_ERR(TAG, "%s:WLink down id error: %d\n", __func__, cam_sfd);
        return -1;
    }
*/

    int camera_index = -1;
    int wifi_sfd = 0;

    wy_info(WLINK_DEBUG,"-----------------------------cmd = 0x%x, dlen = %d\n", cmd, dlen);

    camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

    wifi_sfd = g_CameraBindInfo[camera_index].wifi_ctl_sfd;
    wy_info(WLINK_DEBUG,"wifi_sfd = %d\n", wifi_sfd);
    if (wifi_sfd < 0) {
        IMP_LOG_ERR(TAG, "%s:WLink down id error: %d\n", __func__, wifi_sfd);
        return -1;
    }

    ret = send_pack(wifi_sfd, cmd, data, dlen, flag);
    if (ret < 0) { 
        printf("%s send cmd: %u falied, cam_sfd = %d\n", __func__, cmd, wifi_sfd); 
    }

    return ret; 
}

static int WLink_Cam_Control_No_Data(char *cameraName, uint16_t cmd)
{
    return WLink_Cam_Control(cameraName, cmd, NULL, 0,0);
}

static int WLink_Wifi_Control(const char *cameraName, uint16_t cmd, char *data, uint32_t dlen)
{
    int ret = 0;
    int camera_index = -1;
    int wifi_sfd = 0;

    wy_info(WLINK_DEBUG,"-----------------------------cmd = 0x%x, dlen = %d\n", cmd, dlen);

    camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

    wifi_sfd = g_CameraBindInfo[camera_index].wifi_ctl_sfd;
    wy_info(WLINK_DEBUG,"wifi_sfd = %d\n", wifi_sfd);
    if (wifi_sfd < 0) {
        IMP_LOG_ERR(TAG, "%s:WLink down id error: %d\n", __func__, wifi_sfd);
        return -1;
    }

    ret = send_pack(wifi_sfd, cmd, data, dlen, 0);
    if (ret < 0) {
        printf("%s send cmd: %u falied, wifi_sfd = %d\n", __func__, cmd, wifi_sfd); 
    }

    return ret;
}

static int WLink_Wifi_Control_No_Data(const char *cameraName, uint16_t cmd)
{
    return WLink_Wifi_Control(cameraName, cmd, NULL, 0);
}


/*************** P2P Custom Callback API *** START *************/
static int ZLink_Custom_Video_Switch(int SID, char *cameraName, bool en)
{
    uint16_t cmd;
    int camera_index = -1;

    wy_info(WLINK_DEBUG,"========================%s:%d, SID = %d\n", __func__, __LINE__, SID);
    camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

	if(en) {
		cmd = WLINK_VIDEO_START;
        g_CameraBindInfo[camera_index].video_en_count |= (0x1 << SID);
		IMP_LOG_INFO(TAG, "%s Video En Count:%x\n", cameraName, g_CameraBindInfo[camera_index].video_en_count);
	} else {
		cmd = WLINK_VIDEO_STOP;
        g_CameraBindInfo[camera_index].video_en_count &= ~(0x1 << SID);
		IMP_LOG_INFO(TAG, "%s Video En Count:%x\n", cameraName, g_CameraBindInfo[camera_index].video_en_count);
        if(g_CameraBindInfo[camera_index].video_en_count > 0) {
            return 0;
        }
	}

    return WLink_Cam_Control_No_Data(cameraName, cmd);
}

static int ZLink_Custom_Audio_Switch(int SID, char *cameraName, bool en)
{
    uint16_t cmd;

    wy_info(WLINK_DEBUG,"========================%s:%d, SID = %d\n", __func__, __LINE__, SID);
    int camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

	if(en) {
		cmd = WLINK_AUDIO_START;
		g_CameraBindInfo[camera_index].audio_en_count |= (0x1 << SID);
		IMP_LOG_INFO(TAG, "%s Audio En Count:%x\n", cameraName, g_CameraBindInfo[camera_index].audio_en_count);
	} else {
		cmd = WLINK_AUDIO_STOP;
		g_CameraBindInfo[camera_index].audio_en_count &= ~(0x1 << SID);
		IMP_LOG_INFO(TAG, "%s Audio En Count:%x\n", cameraName, g_CameraBindInfo[camera_index].audio_en_count);
        if(g_CameraBindInfo[camera_index].audio_en_count > 0) {
            return 0;
        }
	}

    return WLink_Cam_Control_No_Data(cameraName, cmd);
}

static int ZLink_Custom_Audio_Play(char *cameraName, unsigned char *buf, int size)
{
    uint16_t cmd = WLINK_CMD_AUDIO_DATA;

    wy_info(WLINK_DEBUG,"========================%s:%d\n", __func__, __LINE__);

    return WLink_Cam_Control(cameraName, cmd, (char*)buf, size,0);
}

static int ZLink_Custom_BindCameraWithZLink(char *cameraName, int SID)
{
    wy_info(WLINK_DEBUG,"========================%s:%d\n", __func__, __LINE__);
	return Camera_Bind_With_P2P(cameraName, SID);
}

static int ZLink_Custom_UnBindCameraWithZLink(char *cameraName, int SID)
{
    wy_info(WLINK_DEBUG,"========================%s:%d\n", __func__, __LINE__);
    wy_wifi_control_close_camera(cameraName, 1);

	int ret = Camera_UnBind_With_P2P(cameraName, SID);
	if(ret < 0) {
		return ret;
	}

#if 0
    int camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

    int i;
	for(i = 0; i < MAX_CLIENT_NUMBER; i++) {
		if(g_CameraBindInfo[camera_index].P2P_SID[i] != -1) {
			break;
		}
	}

	IMP_LOG_INFO(TAG, "Send ZLink Client close\n");

	if(i == MAX_CLIENT_NUMBER) {
        ret = WLink_Wifi_Control_No_Data(cameraName, WIFI_CTRL_CLIENT_CLOSE);
		if(ret < 0) {
			IMP_LOG_ERR(TAG, "Send ZLink Client close failed\n");
		}
	}
#endif

	return ret;
}

int wy_wifi_control_remote_wakeup(const char *cameraName)
{
    IMP_LOG_INFO(TAG, "Send ZLink Client close\n");

   int camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

    g_CameraBindInfo[camera_index].cam_status = CAMERA_STATUS_POWEROFF;
    return WLink_Wifi_Control_No_Data(cameraName, WIFI_CTRL_CAMERA_WAKEUP);
}

int wy_wifi_control_remote_ring(const char *cameraName)
{
    IMP_LOG_INFO(TAG, "Send ZLink Client close\n");

   int camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

    g_CameraBindInfo[camera_index].cam_status = CAMERA_STATUS_POWEROFF;
    return WLink_Wifi_Control_No_Data(cameraName, MSG_TYPE_REMOTE_RING);
}

static int get_recorder_status_locked(CameraBindInfo *camBInfo);
int wy_wifi_control_close_camera(const char *cameraName, int force)
{
    IMP_LOG_INFO(TAG, "Send ZLink Client close\n");

   int camera_index = Camera_Bind_FindCameraIndex_retry(cameraName);
    if (camera_index < 0) {
        return camera_index;
    }

    if (1 == get_recorder_status_locked(&g_CameraBindInfo[camera_index])) {
        if (force) {
            recorder_stop(&g_CameraBindInfo[camera_index], 1);
        } else {
            printf("recorder startting\n");
            return 0;
        }
    }

    if (!force) {
        if (get_camera_connect_phone_count(camera_index) > 1) {
            printf("\n\ncan not close: %s: video_en_count = 0x%x\n", cameraName, g_CameraBindInfo[camera_index].video_en_count);
            return 0;
        }
    }


    if (get_camera_status_set_poweroff(cameraName) == CAMERA_STATUS_POWEROFF) {
        return 0;
    }

    return WLink_Wifi_Control_No_Data(cameraName, WIFI_CTRL_CLIENT_CLOSE);
}

static int ZLink_Custom_CheckCameraStatus(char *cameraName, CAMERA_STATUS *status)
{
	return 0;
}

static int ZLink_Custom_Msg_Process(char *cameraName, char *buf, int size, int cmd, char *result, int maxSize)
{
    int ret;

#if 0
    wy_info(WLINK_DEBUG,"-----------------%s: cmd, 0x%08x, size: %d, ", __func__, cmd, size);
    int i = 0;
    for (i  = 0; i < size; i++) {
        printf("0x%x ", buf[i]);
    }
    printf("\n");
#endif

    ret = WLink_Cam_Control(cameraName, cmd, buf, size,0);
	if(ret < 0) {
		IMP_LOG_ERR(TAG, "%s ZLink_AV_Send_IOCtrl falied\n", __func__);
		return -1;
    }

    ret = ZLink_CMD_Queue_Pop_Timeout(cameraName, cmd, result, maxSize, 8000);
    if(ret < 0) {
        IMP_LOG_ERR(TAG, "%s ZLink_CMD_Queue_Pop_Timeout falied\n", __func__);
        return -1;
    }

    return ret;
}


static int ZLink_Custom_Request_IDR(char *cameraName)
{
    char cmd  = WLINK_VIDEO_REQUEST_IDR;
    wy_info(WLINK_DEBUG,"========================%s:%d\n", __func__, __LINE__);

    return WLink_Cam_Control_No_Data(cameraName, cmd);
}

int wlink_servers_init(void)
{
    int ret;

	Camera_Bind_Info_Init();
    ret = ZLink_Camera_Bind_UpDate();
    if(ret < 0) {
        IMP_LOG_ERR(TAG, "ZLink_Camera_Info_Init Error (%d)\n", ret);
        return -1;
    }

    pthread_t cam_thread;
    ret = pthread_create(&cam_thread, NULL, WLink_Camera_Connect_Server, NULL);
    if(ret != 0) {
        IMP_LOG_ERR(TAG, "ZLink Create Host Thread Error (%d)\n", ret);
        return -1;
    }

    pthread_t wifi_ctl_thread;
    ret = pthread_create(&wifi_ctl_thread, NULL, WLink_Wifi_Ctl_Server, NULL);
    if(ret != 0) {
        IMP_LOG_ERR(TAG, "ZLink Create Host Thread Error (%d)\n", ret);
        return -1;
    }

    return 0;
}

int main_relay_init(void)
{
	int ret = 0;
	//char Host_name[32] = "";


	if(g_P2PCustomFunc.P2P_Custom_Set_CallBack) {
		ZRTP2PCustomCallBack callback = {
			.P2P_Custom_Video_Switch = ZLink_Custom_Video_Switch,
			.P2P_Custom_Audio_Switch = ZLink_Custom_Audio_Switch,
			.P2P_Custom_Audio_Play = ZLink_Custom_Audio_Play,
			.P2P_Custom_BindCameraWithZLink = ZLink_Custom_BindCameraWithZLink,
			.P2P_Custom_UnBindCameraWithZLink = ZLink_Custom_UnBindCameraWithZLink,
			.P2P_Custom_CheckCameraStatus = ZLink_Custom_CheckCameraStatus,
			.P2P_Custom_Msg_Process = ZLink_Custom_Msg_Process,
			.P2P_Custom_Request_IDR = ZLink_Custom_Request_IDR,
		};

		g_P2PCustomFunc.P2P_Custom_Set_CallBack(&callback);
	}

	if(g_P2PCustomFunc.P2P_Custom_Init) {
		ret = g_P2PCustomFunc.P2P_Custom_Init((char*)"UHWXAF17AXLA199M111A", (char*)"admin", (char*)"888888");
		if(ret < 0) {
			IMP_LOG_ERR(TAG, "g_P2PCustomFunc.P2P_Custom_Init failed\n");
			return -1;
		}
	} else {
		IMP_LOG_ERR(TAG, "g_P2PCustomFunc.P2P_Custom_Init is NULL\n");
		return -1;
	}

	//IMP_LOG_INFO(TAG, "ZLink Version: %s\n", ZLink_GetVersion());

	IMP_LOG_INFO(TAG, "ZLink_Host_Init Ok !!!\n");
    

/*
	while(1)
		sleep(1);
*/
	return 0;
}

static int send_result_av_ioctrl_failed(int type, int avIndex)
{
    char result[10];
    int ret;

    result[0] = 0x88;
    ret = avSendIOCtrl(avIndex, type, result, 1);
    if (ret < 0) {
        wy_info(WY_WLINK_API_DEBUG, "avIndex %d: %s error[%X]\n", avIndex, __func__, ret);
    } else {
        wy_info(WY_WLINK_API_DEBUG, "avIndex %d: %s success[%X]\n", avIndex, __func__, ret);
    }

    return ret;
}

int pass_cmd_to_wifi(const char *name, int type, int avIndex, char *buf, int size, int wait)
{
    char result[256] = "";
    int ret = 0;
    struct wheader *pack_ret = NULL;

   int camera_index = Camera_Bind_FindCameraIndex_retry(name);
    if (camera_index < 0) {
        goto cmd_failed;
    }
    if (get_camera_status(name) == CAMERA_STATUS_POWEROFF) {
        goto cmd_failed;
    }
    ret = WLink_Wifi_Control(name, type, buf, size);
	if(ret < 0) {
		IMP_LOG_ERR(TAG, "%s ZLink_AV_Send_IOCtrl falied\n", __func__);
        goto cmd_failed;
    }

    
	ret = ZLink_CMD_Queue_Pop_Timeout(name, type, result, 256, 4000);
    if(ret < 0) {
        IMP_LOG_ERR(TAG, "%s ZLink_CMD_Queue_Pop_Timeout falied\n", __func__);
        goto cmd_failed;
    }
	
	pack_ret = (struct wheader *)result;
	printf("recive flag is %d\n",pack_ret->flag);
    
	if (wait) {
        if (ret > 0) {
            return avSendIOCtrl(avIndex, type, result, ret);
        } else {
            goto cmd_failed;
        }
    }

cmd_failed:
    //return send_result_av_ioctrl_failed(type, avIndex);
#if 1
    if (wait) {
        return send_result_av_ioctrl_failed(type, avIndex);
    } else {
        return ret;
    }
#endif
}

static int pass_cmd_to_camera(const char *name, int type, int avIndex, char *buf, int size, int wait)
{
    char result[256] = "";
    int ret = 0;

   int camera_index = Camera_Bind_FindCameraIndex_retry(name);
    if (camera_index < 0) {
        goto cmd_failed;
    }
    if (get_camera_status(name) == CAMERA_STATUS_POWEROFF) {
        goto cmd_failed;
    }
    ret = WLink_Cam_Control(name, type, buf, size,0);
	if(ret < 0) {
		IMP_LOG_ERR(TAG, "%s ZLink_AV_Send_IOCtrl falied\n", __func__);
        goto cmd_failed;
    }

    ret = ZLink_CMD_Queue_Pop_Timeout(name, type, result, 256, 8000);
    if(ret < 0) {
        IMP_LOG_ERR(TAG, "%s ZLink_CMD_Queue_Pop_Timeout falied\n", __func__);
        goto cmd_failed;
    }

    if (ret > 0) {
        return avSendIOCtrl(avIndex, type, result, ret);
    } else {
        goto cmd_failed;
    }
cmd_failed:
    //return send_result_av_ioctrl_failed(type, avIndex);
#if 1
    if (wait) {
        return send_result_av_ioctrl_failed(type, avIndex);
    } else {
        return ret;
    }
#endif
}
extern int wy_ota_download_file(char *URL, char *fname);
extern int wy_unzip_file(const char *zip, const char * dir);
extern int wy_ota_check_md5(void);
extern int wy_ota_update(void);

int pass_app_to_station(const char *name, int type, int avIndex, char *URL, int size, int wait)
{
	
	char result[256] = "";
	int ret = 0;
	
	struct wy_ota_info *ret_info = NULL;
	ret_info = (struct wy_ota_info *)malloc(sizeof(struct wy_ota_info));
	if(ret_info == NULL){
		printf("malloc ret_info failed \n");
		ret_info->result = 0x04; 
		avSendIOCtrl(avIndex,type,(char *)ret_info,ret);
		return -1;
	}
	ret_info->result = 0;
    
/*    
   	int camera_index = Camera_Bind_FindCameraIndex_retry(name);
    if (camera_index < 0) {
        goto cmd_failed;
    }
    if (get_camera_status(name) == CAMERA_STATUS_POWEROFF) {
        goto cmd_failed;
    }
	
	ret = wy_ota_download_file(URL,"update.zip");
	if(ret != 0){
		printf("download failed \n");
		ret_info.result = 0x04;
		avSendIOCtrl(avIndex,type,result,ret);
		return -1;
	}
*/	
	ret = wy_unzip_file("/lib/update.zip","/lib/");
	if(ret != 0){
		printf("unzip failed \n");
		ret_info->result = 0x04; 
		avSendIOCtrl(avIndex,type,(char *)ret_info,ret);
		return -1;
	}
	
	ret = wy_ota_check_md5();
	if(ret != 0){
		printf("md5 check failed \n");
		ret_info->result = 0x02;
		avSendIOCtrl(avIndex,type,(char *)ret_info,ret);
		return -1;
	}

	ret = wy_ota_update();
	if(ret != 0){
		printf("update failed \n");
		ret_info->result = 0x03; 
		avSendIOCtrl(avIndex,type,(char *)ret_info,ret);
		return -1;
	}
	
	ret_info->result = 0;
	avSendIOCtrl(avIndex,type,(char *)ret_info,ret);
	printf("ota success\n");

//cmd_failed:
#if 1
    if (wait) {
        return send_result_av_ioctrl_failed(type, avIndex);
    } else {
        return ret;
    }
#endif
}


int pass_app_to_camera(const char *name, int type, int avIndex, char *URL, int size, int wait)
{
	const int pack_size = 1024+512;
	int ret = 0;
	FILE *fp = NULL;
	char *buffer = NULL;
	struct wy_ota_info *ret_info;
    struct wheader *pack_ret = NULL;
	
	ret_info = (struct wy_ota_info *)malloc(sizeof(struct wy_ota_info));
	if(ret_info == NULL){
		printf("malloc ret_info failed \n");
		avSendIOCtrl(avIndex,type,(char *)ret_info,ret);
		return -1;
	}

	char result[256] = "x";
	int i;
	struct head_info {
		int flag;
		int seq;
		char pack[pack_size];
	};
	

   	int camera_index = Camera_Bind_FindCameraIndex_retry(name);
    if (camera_index < 0) {
        goto cmd_failed;
    }
    if (get_camera_status(name) == CAMERA_STATUS_POWEROFF) {
        goto cmd_failed;
    }
	
	ret = wy_ota_download_file(URL,"update.zip");
	if(ret != 0){
		printf("download failed \n");
		ret_info->result = 0x04; 
		avSendIOCtrl(avIndex,type,result,ret);
		return -1;
	}
/*下载成功*/	
    ret = WLink_Cam_Control(name,0X1605, URL, size,0);
	if(ret < 0) {
		IMP_LOG_ERR(TAG, "%s ZLink_AV_Send_IOCtrl falied\n", __func__);
        goto cmd_failed;
  	}
 
  	ret = ZLink_CMD_Queue_Pop_Timeout(name, 0x1605, result, 256, 4000);
    if(ret < 0) {
	IMP_LOG_ERR(TAG, "%s ZLink_CMD_Queue_Pop_Timeout falied\n", __func__);
    goto cmd_failed;
    }

     pack_ret = (struct wheader *)result;
  	
	printf("first recive flag is %d\n",pack_ret->flag);
	 if (wait) {
     if (ret >= 0 && (pack_ret->flag == 0)) {

		//file_name为要传给T30的固件的名字，要带绝对路径
		char file_name[64] = "./lib/update.zip";
		fp = fopen(file_name,"w");
   		if(NULL == fp){
   		printf("open file failed!");
   		exit (-1);
		}
	
		//获取当前读取文件的位置 进行保存
		unsigned int current_read_position = ftell(fp);
		int file_size;
		int per_pack_num;

		fseek(fp,0,SEEK_END );
		//获取文件的大小
		file_size = ftell(fp);
		//恢复文件原来读取的位置
		fseek(fp,current_read_position,SEEK_SET);
	
		per_pack_num = (file_size / pack_size) +1;
		printf("file_size = %d, pack_size = %d, per_pack_num = %d\n",file_size,pack_size,per_pack_num);
		struct head_info *pack_head= NULL;
		pack_head = (head_info *)malloc(sizeof(struct head_info));

		buffer = (char *)malloc(1024*100);
		fread(buffer, file_size+1, 1, fp);
		
		for(i = 0; i <= per_pack_num; i++){
			printf("seq = %d  ",i);
			if(i == per_pack_num){
				pack_head->flag = 0x0;
			}
			else{
				pack_head->flag = 0x88;
			}
			pack_head->seq = i;
			strncpy(pack_head->pack, buffer + i * pack_size,pack_size);
	   
			//ret = WLink_Cam_Control(name, type, (char *)pack_head, sizeof(struct head_info));
			ret = WLink_Cam_Control(name, type, buffer + i*pack_size, pack_size,pack_head->flag);
			if(ret < 0) {
				IMP_LOG_ERR(TAG, "%s ZLink_AV_Send_IOCtrl falied\n", __func__);
        		goto cmd_failed;
   			 }
		}
       ret = ZLink_CMD_Queue_Pop_Timeout(name, type, result, 256, 4000);
	   printf("second  flag is %d\n",pack_ret->flag);
       	if(ret < 0) {
        IMP_LOG_ERR(TAG, "%s ZLink_CMD_Queue_Pop_Timeout falied\n", __func__);
        goto cmd_failed;
   		 }

    	if (wait) {
        if (ret > 0) {
            return avSendIOCtrl(avIndex, type, result, ret);
        } else {
            goto cmd_failed;
        	}
    	}
		free(buffer);
		fclose(fp);


	} else {
       goto cmd_failed;
       }
    }
cmd_failed:
    if (wait) {
        return send_result_av_ioctrl_failed(type, avIndex);
    } else {
        return ret;
    }
}

int pass_url_to_wifi(const char *name, int type, int avIndex, char *URL, int size, int wait)
{
	
	int ret;
    char result[256] = "";
    struct wheader *pack_ret = NULL;

	ret = WLink_Wifi_Control(name, 0x1603,"http://192.168.200.39:8080/files/DA16200_RTOS-GEN01-01-9293-000000-0103.img", size);
	if(ret < 0) {
		IMP_LOG_ERR(TAG, "%s ZLink_AV_Send_IOCtrl falied\n", __func__);
        goto cmd_failed;
    }

    ret = ZLink_CMD_Queue_Pop_Timeout(name, 0x1603, result, 256, 8000);
    if(ret < 0) {
        IMP_LOG_ERR(TAG, "%s ZLink_CMD_Queue_Pop_Timeout falied\n", __func__);
        goto cmd_failed;
    }
    
	pack_ret = (struct wheader *)result;
	printf("recive RTOS flag is %d\n",pack_ret->flag);
  	
	if(pack_ret->flag != 0){
		goto cmd_failed;
	}
	
	ret = WLink_Wifi_Control(name, 0x1604,"http://192.168.200.39:8080/files/DA16200_SLIB-GEN01-01-9221-000000-0103.img", size);
	if(ret < 0) {
		IMP_LOG_ERR(TAG, "%s ZLink_AV_Send_IOCtrl falied\n", __func__);
        goto cmd_failed;
    }

    ret = ZLink_CMD_Queue_Pop_Timeout(name, 0x1604, result, 256, 8000);
    if(ret < 0) {
        IMP_LOG_ERR(TAG, "%s ZLink_CMD_Queue_Pop_Timeout falied\n", __func__);
        goto cmd_failed;
    }
	
	printf("recive SLIB flag is %d\n",pack_ret->flag);

	if (ret > 0) {
        return avSendIOCtrl(avIndex, type, result, ret);
    } else {
        goto cmd_failed;
    }
cmd_failed:
    //return send_result_av_ioctrl_failed(type, avIndex);
#if 1
    if (wait) {
        return send_result_av_ioctrl_failed(type, avIndex);
    } else {
        return ret;
    }
#endif
}

int wlink_station_process_ioctl(const char *name, int type, int avIndex, char *buf, int size)
{
    switch (type) {
    case MSG_TYPE_APP_RING_ANSWERED:
        wy_set_ring_status(name, RING_STAT_ANSWERED);
        break;
    case MSG_TYPE_APP_RING_HUNGUP:
        wy_set_ring_status(name, RING_STAT_HUNGUP);
        wy_wifi_control_close_camera(name, 1);
        break;
    case MSG_TYPE_APP_RING_TIMEOUT:
        wy_set_ring_status(name, RING_STAT_TIMEOUT);
        wy_wifi_control_close_camera(name, 0);
        break;
    case MSG_TYPE_REMOTE_RING:
        wy_wifi_control_remote_ring(name);

        break;
    case MSG_TYPE_STATUS_GET_ALL_INFO:
        pass_cmd_to_wifi(name, type, avIndex, buf, size, 1);
        break;

    case MSG_TYPE_OTA_START:
    case MSG_TYPE_OTA_FINISH:
        pass_cmd_to_wifi(name, type, avIndex, buf, size, 0);
        break;
    case MSG_TYPE_OTA_ADDR_STATION:
        //1. 从data 中解析处url;
        //2. 调用本地升级的四个步骤；
        //3. 返回升级状态；
        pass_app_to_station(name, type ,avIndex, buf, size, 0);
		break;
    case MSG_TYPE_OTA_ADDR_CAMERA:
        //1. 从data 中解析出url;
        //2. 下载固件；
        //3. 将固传给camera; WLink_Wifi_Control, cmd: 
        //4. 等待camera 升级完成，返回camera 升级结果；
        pass_app_to_camera(name, type ,avIndex, buf, size, 0);
     	//pass_app_to_camera(name,MSG_TYPE_OTA_T30_STAR,buf,size);
		break;
    case MSG_TYPE_OTA_ADDR_WIFI:
        //1. 从data 中解析出url;
        //2. 将url给wifi 模块;
        //4. 等待camera 升级完成，返回camera 升级结果；
        pass_url_to_wifi(name, type ,avIndex, buf, size, 0);
		break;

    case MSG_TYPE_AUDIO_GET_STA_RING_VOL:
    case MSG_TYPE_AUDIO_GET_PLAY_VOL:
    case MSG_TYPE_RING_LED_GET_ENABLE:
    case MSG_TYPE_GET_FREMOVE:
    case MSG_TYPE_POWER_GET_PIR:
    case MSG_TYPE_VIDEO_GET_IRCUT:
    {
        wy_info(WY_WLINK_API_DEBUG, "\n\ndeprecated msg type: %x, please call MSG_TYPE_STATUS_GET_ALL_INFO, need to fix\n\n", type);
        int on_off = 1;
        int range = 2;
        char buf[8];
        memcpy(buf, &on_off, 4);
        memcpy(buf + 4, &range, 4);
        int ret = avSendIOCtrl(avIndex, type, buf, 8);
        if (ret < 0) {
            wy_info(WY_WLINK_API_DEBUG, "avIndex %d: avSendIOCtrl error[%X]\n", avIndex, ret);
        }

        break;
    }
    case MSG_TYPE_AUDIO_SET_STA_RING_VOL:
    case MSG_TYPE_AUDIO_SET_PLAY_VOL:
    case MSG_TYPE_VIDEO_SET_IRCUT:
    case MSG_TYPE_RING_LED_SET_ENABLE:
    case MSG_TYPE_SET_FREMOVE:
        pass_cmd_to_wifi(name, type, avIndex, buf, size, 0);
        break;

    default:
        pass_cmd_to_camera(name, type, avIndex, buf, size, 0);
        break;
    }

    return 0;
}
